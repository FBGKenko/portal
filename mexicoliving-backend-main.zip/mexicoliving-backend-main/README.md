## Mexico Living Backend

This project was built using [Nest](https://github.com/nestjs/nest) framework TypeScript starter repository.

## Installation

```bash
$ npm install
```

## Running the app

```bash
# development
$ npm run start

# watch mode
$ npm run start:dev

# production mode
$ npm run start:prod
```

## Test

```bash
# unit tests
$ npm run test

# e2e tests
$ npm run test:e2e

# test coverage
$ npm run test:cov
```

## Database

In order to run migrations you need to create a database (PostgreSql) wherever you are going to run this project  (Localhost, your server, etc...).

Once database has been created you need to change db parameters at `src\app.module.ts` line `49`.

Now you can start your project and migrations will be run automatically.

## Note

[TypeORM](https://typeorm.io/) was used to model our database.

## License

Nest is [MIT licensed](LICENSE).
