import { Entity, Column, PrimaryGeneratedColumn, ManyToOne } from 'typeorm';
import { PropertyStatus } from './property-status.model';

@Entity()
export class PropertyStatusI18n {
    @PrimaryGeneratedColumn('increment')
    id: number;

    @Column({ default: 'es' })
    lang: string;

    @Column()
    name: string;

    @ManyToOne(() => PropertyStatus, status => status.i18n)
    status: PropertyStatus;
}