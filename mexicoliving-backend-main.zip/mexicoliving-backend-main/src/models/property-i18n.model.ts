import { Entity, Column, PrimaryGeneratedColumn, ManyToOne } from 'typeorm';
import { Property } from './property.model';

@Entity()
export class PropertyI18n {
    @PrimaryGeneratedColumn('increment')
    id: number;

    @Column({
        default: 'es'
    })
    lang: string;

    @Column({
        default: 'Property'
    })
    name: string;

    @Column()
    description: string;

    @ManyToOne(() => Property, property => property.i18n)
    property: Property;
}