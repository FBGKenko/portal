import { Entity, Column, PrimaryGeneratedColumn, ManyToOne } from 'typeorm';
import { State } from './state.model';

@Entity()
export class StateI18n {
    @PrimaryGeneratedColumn('increment')
    id: number;

    @Column({
        default: 'es'
    })
    lang: string;

    @Column()
    name: string;

    @ManyToOne(() => State, state => state.i18n)
    state: State;
}