import { Entity, Column, PrimaryGeneratedColumn, ManyToOne } from 'typeorm';
import { Complex } from './complex.model';

@Entity()
export class ComplexI18n {
    @PrimaryGeneratedColumn('increment')
    id: number;

    @Column({
        default: 'es'
    })
    lang: string;

    @Column()
    name: string;

    @ManyToOne(() => Complex, complex => complex.i18n)
    complex: Complex;
}