import { Entity, ManyToOne, PrimaryGeneratedColumn, OneToMany, Column } from "typeorm";
import { Timestamps } from "./generic/timestamps";
import { AmenityI18n } from "./amenity-i18n.model";
import { Property } from "./property.model";

@Entity()
export class Amenity extends Timestamps {
    @PrimaryGeneratedColumn('increment')
    id: number;

    @Column({ default: '' })
    iconUrl: string;

    @OneToMany(() => AmenityI18n, i18n => i18n.amenity)
    i18n: AmenityI18n[];

    @ManyToOne(() => Property, property => property.amenities)
    property: Property;
}