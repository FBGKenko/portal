import { Entity, PrimaryGeneratedColumn, OneToMany, ManyToOne, Column } from 'typeorm';
import { CityI18n } from './city-i18n.model';
import { Property } from './property.model';
import { State } from './state.model';

@Entity()
export class City {
    @PrimaryGeneratedColumn('increment')
    id: number;

    @Column({
        default: 'es'
    })
    slug: string;

    @OneToMany(() => CityI18n, i18n => i18n.city)
    i18n: CityI18n[];

    @OneToMany(() => Property, property => property.city)
    properties: Property[];

    @ManyToOne(() => State, state => state.cities)
    state: State;
}