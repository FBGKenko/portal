import { Entity, Column, PrimaryGeneratedColumn, OneToMany } from 'typeorm';
import { CountryI18n } from './country-i18n.model';
import { Property } from './property.model';
import { State } from './state.model';

@Entity()
export class Country {
    @PrimaryGeneratedColumn('increment')
    id: number;

    @Column({
        default: 'es'
    })
    countryCode: string;

    @OneToMany(() => CountryI18n, i18n => i18n.country)
    i18n: CountryI18n[];

    @OneToMany(() => State, state => state.country)
    states: State[];
}