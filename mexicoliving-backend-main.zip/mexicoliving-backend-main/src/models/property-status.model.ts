import { Entity, PrimaryGeneratedColumn, OneToMany, Column } from 'typeorm';
import { PropertyStatusI18n } from './property-status-i18n';
import { Property } from './property.model';

@Entity()
export class PropertyStatus {
    @PrimaryGeneratedColumn('increment')
    id: number;

    @Column({ default: '' })
    slug: string;

    @OneToMany(() => PropertyStatusI18n, i18n => i18n.status)
    i18n: PropertyStatusI18n[];

    @OneToMany(() => Property, property => property.status)
    properties: Property[];
}