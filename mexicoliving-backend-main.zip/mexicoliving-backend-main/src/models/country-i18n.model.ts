import { Entity, Column, PrimaryGeneratedColumn, ManyToOne } from 'typeorm';
import { Country } from './country.model';

@Entity()
export class CountryI18n {
    @PrimaryGeneratedColumn('increment')
    id: number;

    @Column({
        default: 'es'
    })
    lang: string;

    @Column()
    name: string;

    @ManyToOne(() => Country, country => country.i18n)
    country: Country;
}