import { Entity, Column, PrimaryGeneratedColumn, ManyToOne } from 'typeorm';
import { Amenity } from './amenity.model';

@Entity()
export class AmenityI18n {
    @PrimaryGeneratedColumn('increment')
    id: number;

    @Column({
        default: 'es'
    })
    lang: string;

    @Column()
    name: string;

    @ManyToOne(() => Amenity, amenity => amenity.i18n)
    amenity: Amenity;
}