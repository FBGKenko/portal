import { Entity, PrimaryGeneratedColumn, OneToMany, ManyToOne, Column } from 'typeorm';
import { City } from './city.model';
import { Country } from './country.model';
import { StateI18n } from './state-i18n.model';

@Entity()
export class State {
    @PrimaryGeneratedColumn('increment')
    id: number;

    @Column()
    slug: string;

    @OneToMany(() => StateI18n, i18n => i18n.state)
    i18n: StateI18n[];

    @OneToMany(() => City, city => city.state)
    cities: City[];

    @ManyToOne(() => Country, country => country.states)
    country: Country;
}