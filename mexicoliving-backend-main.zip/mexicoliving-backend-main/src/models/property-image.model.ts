import { Entity, Column, PrimaryGeneratedColumn, ManyToOne } from 'typeorm';
import { Property } from './property.model';

@Entity()
export class PropertyImage {
    @PrimaryGeneratedColumn('increment')
    id: number;

    @Column()
    imageUrl: string;

    @ManyToOne(() => Property, property => property.images)
    property: Property;
}