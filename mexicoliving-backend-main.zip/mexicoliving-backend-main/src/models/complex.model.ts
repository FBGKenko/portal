import { Column, Entity, OneToMany, PrimaryGeneratedColumn } from "typeorm";
import { Property } from "./property.model";
import { ComplexI18n } from "./complex-i18n.model";

@Entity()
export class Complex {
    @PrimaryGeneratedColumn('increment')
    id: string;

    @Column({ default: '', unique: true })
    slug: string;

    @OneToMany(() => ComplexI18n, i18n => i18n.complex)
    i18n: ComplexI18n[];

    @OneToMany(() => Property, property => property.complex)
    properties: Property[];
}