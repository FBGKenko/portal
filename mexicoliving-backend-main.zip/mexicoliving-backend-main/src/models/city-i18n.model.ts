import { Entity, Column, PrimaryGeneratedColumn, ManyToOne } from 'typeorm';
import { City } from './city.model';

@Entity()
export class CityI18n {
    @PrimaryGeneratedColumn('increment')
    id: number;

    @Column({
        default: 'es'
    })
    lang: string;

    @Column()
    name: string;

    @ManyToOne(() => City, city => city.i18n)
    city: City;
}