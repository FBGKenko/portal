import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne } from 'typeorm';
import { City } from './city.model';
import { Country } from './country.model';
import { PropertyI18n } from './property-i18n.model';
import { PropertyStatus } from './property-status.model';
import { PropertyImage } from './property-image.model';
import { Complex } from './complex.model';
import { Timestamps } from './generic/timestamps';
import { Amenity } from '.';

@Entity()
export class Property extends Timestamps {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    @Column({
        default: 0,
        type: 'decimal'
    })
    rooms: number;

    @Column({
        default: 0,
        type: 'decimal'
    })
    surface: number;
    
    @Column({
        default: 0,
        type: 'decimal'
    })
    bathrooms: number;
    
    @Column({
        default: 0,
        type: 'decimal'
    })
    parking_spaces: number;

    @Column({
        default: 0,
        type: 'decimal'
    })
    price: number;

    @Column({
        default: ''
    })
    mainImageUrl: string;

    @Column({ default: false })
    highlighted: boolean;

   @OneToMany(() => PropertyI18n, i18n => i18n.property)
    i18n: PropertyI18n[];

   @OneToMany(() => PropertyImage, image => image.property)
    images: PropertyImage[];
   
    @ManyToOne(() => City, city => city.properties)
    city: City;

    @ManyToOne(() => Complex, complex => complex)
    complex: Complex;

    @ManyToOne(() => PropertyStatus, status => status)
    status: PropertyStatus;

    @OneToMany(() => Amenity, amenity => amenity.property)
    amenities: Amenity[];
}