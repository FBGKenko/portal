import { Injectable } from '@nestjs/common';
import { MailerService } from '@nestjs-modules/mailer';

@Injectable()
export class AppService {
  constructor(
    private readonly mailerService: MailerService
  ) {}

  getHello(): string {
    return 'Hello World!';
  }

  newsLetterSubscribe(params: { fullname: string, email: string }): Promise<string> {
    return this.mailerService
      .sendMail({
        to: 'isaac.mexicoliving@yopmail.com',
        from: 'noreply@mexicoliving.com',
        subject: 'Subscribe to newsletter [Request]',
        template: 'src/templates/newsletter.ejs',
        attachments: [
          {
            filename: 'logo.png',
            path: 'src/templates/images/h1.png',
            cid: 'mexicolivinglogo'
          },
          {
            filename: 'instagram.png',
            path: 'src/templates/images/instagram.png',
            cid: 'instagramLogo'
          }
        ],
        context: {
          fullname: params.fullname,
          email: params.email,
        }
      }).then(() => {
        return 'Email sent successfully.'
      }).catch((error) => {
        console.log(error);
        return 'Something went wrong.'
      })
  }

  contact(params: { fullname: string, email: string, type: string, readyToPurchase: string, justExploring: string, budget: string }): Promise<string> {
    return this.mailerService
      .sendMail({
        to: 'isaac.mexicoliving@yopmail.com',
        from: 'noreply@mexicoliving.com',
        subject: 'Contact [Request]',
        template: 'src/templates/contact.ejs',
        attachments: [
          {
            filename: 'logo.png',
            path: 'src/templates/images/h1.png',
            cid: 'mexicolivinglogo'
          },
          {
            filename: 'instagram.png',
            path: 'src/templates/images/instagram.png',
            cid: 'instagramLogo'
          }
        ],
        context: {
          fullname: params.fullname,
          email: params.email,
          type: params.type,
          readyToPurchase: Boolean(params.readyToPurchase) ? 'Si' : 'No',
          justExploring: Boolean(params.justExploring) ? 'Si' : 'No',
          budget: params.budget,
        }
      }).then(() => {
        return 'Email sent successfully.'
      }).catch((error) => {
        console.log(error);
        return 'Something went wrong.'
      })
  }
}
