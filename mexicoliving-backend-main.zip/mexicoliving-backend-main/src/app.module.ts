import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MailerModule } from '@nestjs-modules/mailer';
import { EjsAdapter } from '@nestjs-modules/mailer/dist/adapters/ejs.adapter';
import {
  Property,
  PropertyI18n,
  PropertyStatus,
  PropertyStatusI18n,
  Country,
  CountryI18n,
  State,
  StateI18n,
  City,
  CityI18n,
  PropertyImage,
  Complex,
  ComplexI18n,
  Amenity,
  AmenityI18n
} from './models';
import { PropertiesModule } from './modules/properties/properties.module';
import { CitiesModule } from './modules/cities/cities.module';

@Module({
  imports: [
    MailerModule.forRoot({
      // transport: 'smtps://isaacv2514@gmail.com:chivas1410@smtp.gmail.com',
      transport: {
        service: 'Gmail',
        auth: {
          user: "isaacv2514@gmail.com",
          pass: "chivas1410"
        }
      },
      defaults: {
        from: '"nest-modules" <modules@nestjs.com>',
      },
      template: {
        dir: __dirname + '/templates',
        adapter: new EjsAdapter(),
        options: {
          strict: false,
        },
      },
    }),
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: '127.0.0.1',
      port: 5432,
      username: 'postgres',
      password: 'root',
      database: 'mexicoliving',
      entities: [
        PropertyI18n,
        Property,
        PropertyStatus,
        PropertyStatusI18n,
        Country,
        CountryI18n,
        State,
        StateI18n,
        City,
        CityI18n,
        PropertyImage,
        Complex,
        ComplexI18n,
        Amenity,
        AmenityI18n
      ],
      synchronize: true,
    }),
    PropertiesModule,
    CitiesModule
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
