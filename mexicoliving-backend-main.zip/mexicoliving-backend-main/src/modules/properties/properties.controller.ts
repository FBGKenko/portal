import { Body, Controller, Get, Param, Post, Query } from "@nestjs/common";
import { Pagination } from "src/interfaces";
import { City, Property, PropertyStatus } from "src/models";
import { PropertiesService } from "./properties.service";

@Controller('properties')
export class PropertiesController {
    constructor(
        private readonly propertiesService: PropertiesService
    ) {}

    @Get('all')
    async findAll(@Query() query: { page: number, orderBy: string, orderDirection: string, cityId?: number, statusId?: number, budget?: number }): Promise<Pagination<Property>> {
        return this.propertiesService.getWithPagination({ ...query });
    }

    @Post('random')
    async getRandomProperties(@Body() params: { propertiesToAvoid: string[] }): Promise<Property[]> {
        return this.propertiesService.getRandomProperties(params.propertiesToAvoid);
    }

    @Get('statuses')
    async getPropertyStatuses(): Promise<PropertyStatus[]> {
        return this.propertiesService.getPropertyStatuses();
    }

    @Get('cities')
    async getCities(): Promise<City[]> {
        return this.propertiesService.getCities();
    }

    @Get('detail/:id')
    async getById(@Param() params: { id: string }): Promise<Property> {
        return this.propertiesService.getById(params.id);
    }

    @Get('hightlighted')
    getHightlightedProperties(): Promise<Property[]> {
        return this.propertiesService.getHightlightedProperties();
    }
}