import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import {
    Property,
    PropertyI18n,
    PropertyStatus,
    PropertyStatusI18n,
    Country,
    CountryI18n,
    State,
    StateI18n,
    City,
    CityI18n,
    PropertyImage,
    Complex,
    ComplexI18n,
    Amenity,
    AmenityI18n
} from '../../models';
import { PropertiesController } from './properties.controller';
import { PropertiesService } from './properties.service';

@Module({
    imports: [
        TypeOrmModule.forFeature([
            PropertyStatus,
            PropertyStatusI18n,
            Property,
            PropertyI18n,
            Country,
            CountryI18n,
            State,
            StateI18n,
            City,
            CityI18n,
            PropertyImage,
            Complex,
            ComplexI18n,
            Amenity,
            AmenityI18n
        ])
    ],
    exports: [
        TypeOrmModule
    ],
    providers: [PropertiesService],
    controllers: [PropertiesController]
})
export class PropertiesModule {}