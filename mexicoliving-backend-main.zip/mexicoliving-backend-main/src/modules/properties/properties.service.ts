import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Amenity, City, Property, PropertyStatus } from '../../models';
import { Pagination, PaginationParams } from '../../interfaces';

@Injectable()
export class PropertiesService {
    constructor(
        @InjectRepository(Property)
        private readonly propertyRepository: Repository<Property>,
        @InjectRepository(PropertyStatus)
        private readonly pStatusRepository: Repository<PropertyStatus>,
        @InjectRepository(City)
        private readonly cityRepository: Repository<City>,
    ) {}

    async getWithPagination(params: { orderBy: string, orderDirection: string, page: number, cityId?: number, statusId?: number, budget?: number }): Promise<Pagination<Property>> {
        console.log(params.cityId);
        let query = this.propertyRepository
            .createQueryBuilder('property')
            .innerJoinAndSelect('property.i18n', "i18n")
            .innerJoinAndSelect('property.status', 'status')
            .innerJoinAndSelect('status.i18n', 'statusI18n')
            .innerJoinAndSelect('property.city', 'city')
            .innerJoinAndSelect('city.i18n', 'cityI18n')
            .innerJoinAndSelect('property.complex', 'complex')
            .innerJoinAndSelect('complex.i18n', 'complexI18n');
          
        if (params.cityId) {
            query = query.andWhere('city.id = :cityId', { cityId: params.cityId });
        }

        if (params.statusId) {
            query = query.andWhere('status.id = :statusId', { statusId: params.statusId });
        }

        if (Number(params.budget)) {
            query = query.andWhere('property.price >= :min', { min: 0 }).andWhere('property.price <= :max', { max: params.budget });
        }
         
        const allProperties = await query.getMany();

        const totalItems = allProperties.length;
        const totalPages = Math.ceil(totalItems / 12);
        let pageBefore = null;
        let nextPage = null;

        if (params.page < totalPages) {
            nextPage = Number(params.page) + 1;
        }
        
        if (params.page > 1) {
            pageBefore = Number(params.page) - 1;
        }

        const offset = params.page === 1 ? 0 : (params.page - 1) * 12;
        const limit = offset === 0 ? offset + 12 : offset + 12;

        return Promise.resolve({
            items: allProperties.slice(offset, limit),
            pagination: {
                page: params.page,
                nextPage,
                pageBefore,
                totalPages,
                totalItems
            }
        });
    }

    async getRandomProperties(propertiesToAvoid: string[] = []): Promise<Property[]> {
        const query = this.propertyRepository
            .createQueryBuilder('property')
            .innerJoinAndSelect('property.i18n', "i18n")
            .innerJoinAndSelect('property.status', 'status')
            .innerJoinAndSelect('status.i18n', 'statusI18n')
            .innerJoinAndSelect('property.city', 'city')
            .innerJoinAndSelect('city.i18n', 'cityI18n')
            .innerJoinAndSelect('property.complex', 'complex')
            .innerJoinAndSelect('complex.i18n', 'complexI18n')
            .innerJoinAndSelect('property.images', 'images')

        if (propertiesToAvoid.length) {
            query.where('property.id NOT IN (:...propertiesToAvoid)', { propertiesToAvoid });
        }

        const totalProperties = await this.propertyRepository.count();
        const randomIndex = Math.floor(Math.random() * (totalProperties - 8));

        return query
            .getMany();
    }

    getPropertyStatuses(): Promise<PropertyStatus[]> {
        return this.pStatusRepository
            .createQueryBuilder('propertyStatus')
            .innerJoinAndSelect('propertyStatus.i18n', 'i18n')
            .getMany();
    }

    async getCities(): Promise<City[]> {
        const cities = await this.cityRepository
            .createQueryBuilder('city')
            .innerJoinAndSelect('city.i18n', 'i18n')
            .innerJoinAndSelect('city.properties', 'properties')
            .getMany();

        return cities.map((city) => ({ ...city, properties: undefined }))
    }

    async getById(id: string): Promise<Property> {
        const query = this.propertyRepository
            .createQueryBuilder('property')
            .innerJoinAndSelect('property.i18n', "i18n")
            .innerJoinAndSelect('property.status', 'status')
            .innerJoinAndSelect('status.i18n', 'statusI18n')
            .innerJoinAndSelect('property.city', 'city')
            .innerJoinAndSelect('city.i18n', 'cityI18n')
            .innerJoinAndSelect('city.state', 'state')
            .innerJoinAndSelect('state.i18n', 'stateI18n')
            .innerJoinAndSelect('property.images', 'images')
            .innerJoinAndSelect('property.complex', 'complex')
            .innerJoinAndSelect('complex.i18n', 'complexI18n')
            .innerJoinAndSelect('property.amenities', 'amenities')
            .innerJoinAndSelect('amenities.i18n', 'amenityI18n')
            .where('property.id = :id', { id })

        const property = await query.getOne();
        return property;
    }

    async getHightlightedProperties(): Promise<Property[]> {
        let query = this.propertyRepository
            .createQueryBuilder('property')
            .innerJoinAndSelect('property.i18n', "i18n")
            .innerJoinAndSelect('property.status', 'status')
            .innerJoinAndSelect('status.i18n', 'statusI18n')
            .innerJoinAndSelect('property.city', 'city')
            .innerJoinAndSelect('city.i18n', 'cityI18n')
            .innerJoinAndSelect('property.complex', 'complex')
            .innerJoinAndSelect('complex.i18n', 'complexI18n')
            .where('property.highlighted = :highlighted', { highlighted: true });
        
        const allProperties = await query.getMany();

        return allProperties;
        
    }
}