import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { QueryBuilder, Repository } from 'typeorm';
import { City } from '../../models';

@Injectable()
export class CitiesService {
    constructor(
        @InjectRepository(City)
        private cityRepository: Repository<City>
    ) {}

    getAll(): Promise<City[]> {
        return this.cityRepository
            .createQueryBuilder('city')
            .innerJoinAndSelect('city.i18n', 'i18n')
            .getMany();
    }
}