import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import {
    City,
    CityI18n
} from '../../models';
import { CitiesController } from './cities.controller';
import { CitiesService } from './cities.service';

@Module({
    imports: [
        TypeOrmModule.forFeature([
            City,
            CityI18n
        ])
    ],
    exports: [
        TypeOrmModule
    ],
    providers: [CitiesService],
    controllers: [CitiesController]
})
export class CitiesModule {}