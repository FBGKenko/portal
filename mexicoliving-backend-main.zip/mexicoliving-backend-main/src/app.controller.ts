import { Controller, Get, Post, Body } from '@nestjs/common';
import { AppService } from './app.service';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get()
  getHello(): string {
    return this.appService.getHello();
  }

  @Post('subscribe-newsletter')
  newsLetterSubscribe(@Body() params: { fullname: string, email: string }): Promise<string> {
    return this.appService.newsLetterSubscribe(params)
      .then(response => response)
      .catch(error => error);
  }

  @Post('contact')
  contact(@Body() params: { fullname: string, email: string, type: string, readyToPurchase: string, justExploring: string, budget: string }): Promise<string> {
    return this.appService.contact(params)
      .then(response => response)
      .catch(error => error);
  }
}
