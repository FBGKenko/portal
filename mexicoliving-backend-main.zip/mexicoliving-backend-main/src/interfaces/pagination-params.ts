export interface PaginationParams {
    page: number;
    orderBy: string;
    orderDirection: string;
}