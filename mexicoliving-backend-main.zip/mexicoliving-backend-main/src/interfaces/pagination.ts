export interface Pagination<T> {
    items: T[];
    pagination: {
        page: number,
        nextPage: number;
        pageBefore: number;
        totalPages: number;
        totalItems: number;
    };
}