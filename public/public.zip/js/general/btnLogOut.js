$('#btnInicio').click(function () { 
    window.location.href = $(this).attr('name');    
});

$('#btnLogIn').click(function () { 
    window.location.href = $(this).attr('name');
});

