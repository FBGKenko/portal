
<?php $__env->startSection('titulo'); ?>
    Perfil
<?php $__env->stopSection(); ?>
<?php $__env->startSection('cuerpo'); ?>
    <header class="clearfix border border-3 p-2">
        <?php if (isset($component)) { $__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9 = $component; } ?>
<?php $component = App\View\Components\Menu::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Menu::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9)): ?>
<?php $component = $__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9; ?>
<?php unset($__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9); ?>
<?php endif; ?>
    </header>
    <main>
        <div class="col-7 mt-3 mx-auto d-flex justify-content-between">
            <h3 class="col-auto mt-0 mx-1 fw-bold">Datos personales</h3>
            <label class="container col-auto mx-4">Activar
                <input type="checkbox" id="cbMostrarContra">
                <span class="checkmark mt-1"></span>
            </label>
        </div>
        <div class="col-7 mx-auto bg-secondary bg-opacity-25 p-2">
            <h3 class="ms-4"><span class="fw-bold">Nombre:</span> <?php echo e(session('usuario')->nombres); ?></h3>
            <h3 class="ms-4"><span class="fw-bold">Apellidos:</span> <?php echo e(session('usuario')->apellidos); ?></h3>
            <h3 class="ms-4"><span class="fw-bold">Telefono:</span> <?php echo e(session('usuario')->telefono); ?></h3>
            <h3 class="ms-4"><span class="fw-bold">Correo:</span> <?php echo e(session('usuario')->correo); ?></h3>
            <h3 class="ms-4"><span class="fw-bold">Fecha de nacimiento:</span> <?php echo e(session('usuario')->cumpleanios); ?></h3>
        </div>
        
        <?php if(isset($empresa)): ?>
            <h3 class="col-7 mx-auto mt-3 fw-bold">Datos de la empresa</h3>
            <div class="col-7 mx-auto bg-secondary bg-opacity-25 p-2">
                <article class="">
                    <h3 class="ms-4"><span class="fw-bold">Razon social:</span> <?php echo e($empresa->razonSocial); ?></h3>
                    <h3 class="ms-4"><span class="fw-bold">Correo empresa:</span> <?php echo e($empresa->correoEmpresa); ?></h3>
                    <h3 class="ms-4"><span class="fw-bold">Telefono empresa:</span> <?php echo e($empresa->telefonoEmpresa); ?></h3>
                    <h3 class="ms-4"><span class="fw-bold">Pagina web:</span> <?php echo e($empresa->paginaWeb); ?></h3>
                </article>
            </div>
        <?php endif; ?>
        <div class="col-7 mt-3 mx-auto d-flex justify-content-between">
            <h3 class="col-auto mt-0 mx-1">Datos fiscales</h3>
            <label class="container col-auto mx-4">Activar
                <input type="checkbox" id="cbMostrarContra">
                <span class="checkmark mt-1"></span>
            </label>
        </div>
        <div class="col-7 mx-auto bg-secondary bg-opacity-25 p-2">
            <h3 class="ms-4"><span class="fw-bold">RFC:</span> <?php echo e(session('usuario')->nombres); ?></h3>
            <h3 class="ms-4"><span class="fw-bold">Tipo de persona:</span> <?php echo e(session('usuario')->apellidos); ?></h3>
            <h3 class="ms-4"><span class="fw-bold">Domicilio fiscal:</span> <?php echo e(session('usuario')->telefono); ?></h3>
        </div>
        <div class="col-7 mt-3 mx-auto d-flex justify-content-between">
            <h3 class="col-auto mt-0 mx-1 fw-bold">Datos de domicilio</h3>
            <label class="container col-auto mx-4">Activar
                <input type="checkbox" id="cbMostrarContra">
                <span class="checkmark mt-1"></span>
            </label>
        </div>
        <div class="col-7 mx-auto bg-secondary bg-opacity-25 p-2">
            <h3 class="ms-4"><span class="fw-bold">Calle:</span> <?php echo e(session('usuario')->nombres); ?></h3>
            <h3 class="ms-4"><span class="fw-bold">No de exterior:</span> <?php echo e(session('usuario')->apellidos); ?></h3>
            <h3 class="ms-4"><span class="fw-bold">Colonia:</span> <?php echo e(session('usuario')->telefono); ?></h3>
            <h3 class="ms-4"><span class="fw-bold">Código postal:</span> <?php echo e(session('usuario')->correo); ?></h3>
            <h3 class="ms-4"><span class="fw-bold">Ciudad:</span> <?php echo e(session('usuario')->cumpleanios); ?></h3>
            <h3 class="ms-4"><span class="fw-bold">Estado:</span> <?php echo e(session('usuario')->cumpleanios); ?></h3>
            <h3 class="ms-4"><span class="fw-bold">Referencia:</span> <?php echo e(session('usuario')->cumpleanios); ?></h3>
        </div>
        <div class="col-7 mt-3 mx-auto d-flex justify-content-between">
            <h3 class="col-auto mt-0 mx-1 fw-bold">Datos bancarios</h3>
            <label class="container col-auto mx-4">Activar
                <input type="checkbox" id="cbMostrarContra">
                <span class="checkmark mt-1"></span>
            </label>
        </div>
        <div class="col-7 mx-auto bg-secondary bg-opacity-25 p-2 mb-4">
            <h3 class="ms-4"><span class="fw-bold">Número de tarjeta:</span> <?php echo e(session('usuario')->nombres); ?></h3>
            <h3 class="ms-4"><span class="fw-bold">Clabe:</span> <?php echo e(session('usuario')->apellidos); ?></h3>
            <h3 class="ms-4"><span class="fw-bold">Banco:</span> <?php echo e(session('usuario')->telefono); ?></h3>
            <h3 class="ms-4"><span class="fw-bold">Nombre completo registrado al banco:</span> <?php echo e(session('usuario')->telefono); ?></h3>
        </div>

           
    </main>
    <footer>
    </footer>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="/js/principal.js"></script>
    <script>
        function openLeftMenu() {
        document.getElementById("leftMenu").style.display = "block";
        }

        function closeLeftMenu() {
        document.getElementById("leftMenu").style.display = "none";
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.plantillaMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views/perfil.blade.php ENDPATH**/ ?>