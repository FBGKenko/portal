
<?php $__env->startSection('titulo'); ?>
    Permisos
<?php $__env->stopSection(); ?>
<?php $__env->startSection('cuerpo'); ?>
<header class="clearfix border border-3 p-2">
    <?php if (isset($component)) { $__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3 = $component; } ?>
<?php $component = App\View\Components\Menu::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Menu::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3)): ?>
<?php $component = $__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3; ?>
<?php unset($__componentOriginaldadc8f6aa159c05f9151bf94d661e8e3); ?>
<?php endif; ?>
</header>
<main>
    <form action="<?php echo e(route('permisos.change')); ?>" class="" method="post" id="formPermisos">
        <div class="col-9 mx-auto mt-3 d-flex">
            <span class="fs-4">Permitir a la empresa: </span>
            <select class="form-select w-25 form-select-lg mb-3 mx-3" aria-label=".form-select-lg example" name="empresaSelect">
                <option selected>Selecciona una empresa</option>
                <?php $__currentLoopData = $empresasSiguiendo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($e->id); ?>"><?php echo e($e->razonSocial); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            <span class="fs-4"> los siguientes datos</span>
        </div>
        <div class="border p-4 m-2 col-9 mx-auto">
            <?php echo csrf_field(); ?>
            <Span class="fs-4">Compartir</Span>
            <div class="d-flex justify-content-center">
                <label class="container col-auto mx-1">Datos personales
                    <input type="checkbox" id="cbDatosPersonal" name="cbDPersonal">
                    <span class="checkmark mt-1"></span>
                </label>
                <label class="container col-auto mx-1">Datos fiscales
                    <input type="checkbox" id="cbDatosFiscal" name="cbDFiscal">
                    <span class="checkmark mt-1"></span>
                </label>
                <label class="container col-auto mx-1">Datos de domicilio
                    <input type="checkbox" id="cbDatosDomicilio" name="cbDDomicilio">
                    <span class="checkmark mt-1"></span>
                </label>
                <label class="container col-auto mx-1">Datos bancarios
                    <input type="checkbox" id="cbDatosBancario" name="cbDBancario">
                    <span class="checkmark mt-1"></span>
                </label>
            </div>
            <div class="text-center mt-5">
                <input type="submit" class="col-auto btn btn-primary fw-bold border border-dark" id="btnPermisos" value="Cambiar permisos">
            </div>
        </div>
    </form>
</main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="/js/principal.js"></script>
    <script src="/js/matrizPermisos.js"></script>
        <script>
            function openLeftMenu() {
                document.getElementById("leftMenu").style.display = "block";
            }

            function closeLeftMenu() {
                document.getElementById("leftMenu").style.display = "none";
            }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantillaMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views/matrizPermisosDatos.blade.php ENDPATH**/ ?>