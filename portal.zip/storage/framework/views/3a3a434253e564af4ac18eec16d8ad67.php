
<?php $__env->startSection('titulo'); ?>
    Cambiar contraseña
<?php $__env->stopSection(); ?>
<?php $__env->startSection('cuerpo'); ?>
    <header class="clearfix border border-3 p-3">
        <button id="btnInicio" name="<?php echo e(route('index')); ?>" class='btn bg-success bg-gradient text-white float-end me-5 fw-bold'>Inicio</button>
        <button id="btnLogIn" name="<?php echo e(route('login')); ?>" class='btn bg-success bg-gradient text-white float-end me-5 fw-bold'>Iniciar sesión</button>
    </header>
    <main>
        <article class="d-flex justify-content-center">
            <form class="col-4 bg-secondary text-center rounded-3 mt-5 p-5 pt-3" id="formCC" action="<?php echo e(route('CCC', $token->token)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <h3 class="fw-bold text-white">CAMBIAR CONTRASEÑA</h3>
                <input class="col-9 mb-3" id="txtContra1" name="txtContra1" placeholder="Nueva contraseña" minlength="8" maxlength="20" type="password">
                <input class="col-9 mb-3" id="txtContra2" name="txtContra2" placeholder="Repetir contraseña" minlength="8" maxlength="20" type="password">
                <div class="mx-auto">
                    <label class="container col-6 text-white">Mostrar contraseña
                        <input type="checkbox" id="cbMostrarContra">
                        <span class="checkmark mt-1"></span>
                    </label>
                </div>
                <div class="mt-3">
                    <input class="col-7 btn btn-success fw-bold border border-dark" type="submit" id="btnCC" name="<?php echo e(route('login')); ?>" value="Confirmar">
                </div>
            </form>
        </article>
    </main>
    <footer>
    </footer>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="/js/bootstrap.bundle.min.js"></script>
    <script src="/js/cambiarContra.js"></script>
    <script src="/js/general/btnLogOut.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.plantillaMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views/cambiarContraseña.blade.php ENDPATH**/ ?>