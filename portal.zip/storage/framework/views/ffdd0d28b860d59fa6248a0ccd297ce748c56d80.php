<div>
    <div class="d-flex justify-content-center">
        <label class="container col-auto mx-1">Datos personales
            <input type="checkbox" id="cbDatosPersonal" name="cbDPersonal">
            <span class="checkmark mt-1"></span>
        </label>
        <label class="container col-auto mx-1">Datos fiscales
            <input type="checkbox" id="cbDatosFiscal" name="cbDFiscal">
            <span class="checkmark mt-1"></span>
        </label>
        <label class="container col-auto mx-1">Datos de domicilio
            <input type="checkbox" id="cbDatosDomicilio" name="cbDDomicilio">
            <span class="checkmark mt-1"></span>
        </label>
        <label class="container col-auto mx-1">Datos bancarios
            <input type="checkbox" id="cbDatosBancario" name="cbDBancario">
            <span class="checkmark mt-1"></span>
        </label>
    </div>
</div>
<?php /**PATH C:\laragon\www\portal\resources\views/livewire/permisos.blade.php ENDPATH**/ ?>