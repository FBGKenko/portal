
<?php $__env->startSection('titulo'); ?>
    Configuración
<?php $__env->stopSection(); ?>
<?php $__env->startSection('cuerpo'); ?>
    <header class="clearfix border border-3 p-2">
        <?php if (isset($component)) { $__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9 = $component; } ?>
<?php $component = App\View\Components\Menu::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Menu::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9)): ?>
<?php $component = $__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9; ?>
<?php unset($__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9); ?>
<?php endif; ?>
    </header>
    <main>
        
        <!--
        FORMULARIO CAMBIAR INFORMACION PERSONAL 
        -->
        <form action="<?php echo e(route('config.infoP')); ?>" id="formInfoPersonal" method="POST" class="col-6 text-center rounded-3 mt-3 p-5 pt-3 mx-auto">
            <?php echo csrf_field(); ?>
            <h3 class="fw-bold">Datos personales</h3>
            <div class="d-flex justify-content-center">
                <div>
                    <input type="email" class="col-9 mb-3 fs-5" placeholder="Correo" name="txtCorreo" id="txtCorreo" 
                    minlength="4" maxlength="50">
                    <input type="text" class="col-9 mb-3 fs-5" placeholder="Telefono" name="txtTelefono" id="txtTelefono" 
                    minlength="10" maxlength="15">
                </div>
                <div>
                    <input type="text" class="col-9 mb-3 fs-5" placeholder="Nombres" name="txtNombres" id="txtNombres" 
                    minlength="3" maxlength="50">
                    <input type="text" class="col-9 mb-3 fs-5" placeholder="Apellidos" name="txtApellidos" id="txtApellidos" 
                    minlength="3" maxlength="50">
                </div>
            </div>
            <div class="mt-3">
                <input type="submit" id="btnCambiar" value="Cambiar información" class="col-auto btn btn-primary fw-bold border border-dark">
            </div>
        </form>
        <!-- 
        FORMULARIO CAMBIAR CONTRASEÑA
        -->
        <form action="<?php echo e(route('config.cC')); ?>" id="formCC" method="POST" class="col-4 text-center rounded-3 mt-3 p-5 pt-3 mx-auto">
            <?php echo csrf_field(); ?>
            <h3 class="fw-bold">Cambiar contraseña</h3>
            <input type="password" class="col-9 mb-3 fs-5" placeholder="Contraseña nueva" name="txtContra1" id="txtContra1" 
            minlength="8" maxlength="20">
            <input type="password" class="col-9 mb-3 fs-5" placeholder="Repetir contraseña nueva" name="txtContra2" id="txtContra2"
            minlength="8" maxlength="20">
            <div class="mx-auto">
                <label class="container col-6">Mostrar contraseña
                    <input type="checkbox" id="cbMostrarContra">
                    <span class="checkmark mt-1"></span>
                </label>
            </div>
            <div class="mt-3">
                <input type="submit" id="btnCC" value="Cambiar contraseña" class="col-auto btn btn-primary fw-bold border border-dark">
            </div>
        </form>
        <div class="col-4 mx-auto text-center">
            <h3 class="fw-bold">Configuración de permisos</h3>
            <div class="mt-3">
                <input class="col-auto btn btn-primary fw-bold border border-dark" type="button" id="btnPermisos" value="Administrar permisos" name="<?php echo e(route('permisos')); ?>">
            </div>
        </div>
        <!-- 
        BOTON PARA CAMBIAR AVISO DE PRIVACIDAD
        <form action="<?php echo e(route('config.privacidad')); ?>" class="mt-5 mx-auto col-5" method="GET" id="formCPrivacidad" name="formCPrivacidad">
            <h3 class="fw-bold text-center">Aviso de privacidad</h3>
            <label class="container col-7">Que las empresas tengan acceso a mis datos personales
                <?php if($config->datosPrivados == "N"): ?>
                    <input name="cbPrivacidad" type="checkbox" id="cbPrivacidad" checked>                        
                <?php else: ?>
                    <input name="cbPrivacidad" type="checkbox" id="cbPrivacidad">
                <?php endif; ?>
                <span class="checkmark mt-2"></span>
            </label>
        </form>
        -->
        
        <!--
        CAMBIAR CMODO OSCURO
            <article class="mt-5 mx-auto col-5">
                <h3 class="fw-bold text-center">Modo oscuro</h3>
                <label class="container col-7">Activar modo oscuro
                    <input type="checkbox" id="cbModoOscuro">
                    <span class="checkmark mt-2"></span>
                </label>
            </article>
        -->
   </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="/js/principal.js"></script>
    <script src="/js/configuracion.js"></script>
    <script>
        function openLeftMenu() {
        document.getElementById("leftMenu").style.display = "block";
        }

        function closeLeftMenu() {
        document.getElementById("leftMenu").style.display = "none";
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantillaMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views/configuracion.blade.php ENDPATH**/ ?>