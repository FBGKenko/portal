
<?php $__env->startSection('titulo'); ?>
    Olvide contraseña
<?php $__env->stopSection(); ?>
<?php $__env->startSection('cuerpo'); ?>
    <header class="clearfix border border-3 p-3">
        <button id="btnInicio" name="<?php echo e(route('index')); ?>" class='btn bg-success bg-gradient text-white float-end me-5 fw-bold'>Inicio</button>
        <button id="btnLogIn" name="<?php echo e(route('login')); ?>" class='btn bg-success bg-gradient text-white float-end me-5 fw-bold'>Iniciar sesión</button>
    </header>
    <main>
        <article class="d-flex justify-content-center">
            <form class="col-4 bg-secondary text-center rounded-3 mt-5 p-5 pt-3" id="formOlvide" action="<?php echo e(route('enviarCC')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <h3 class="fw-bold text-white">OLVIDE MI CONTRASEÑA</h3>
                <p class="text-center text-light">Le enviaremos un correo para restaurar su contraseña, ingrese su correo.</p>
                <input class="col-9 mb-3" id="txtCorreo" name="txtCorreo" placeholder="Correo" type="text">
                <div class="mt-3">
                    <input class="col-7 btn btn-success fw-bold border border-dark" type="submit" id="btnOlvide" value="Confirmar">
                </div>
            </form>
        </article>
    </main>
    <footer>
    </footer>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="/js/bootstrap.bundle.min.js"></script>
    <script src="/js/olvideContra.js"></script>
    <script src="/js/general/btnLogOut.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.plantillaMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views/olvideContra.blade.php ENDPATH**/ ?>