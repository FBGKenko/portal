
<?php $__env->startSection('titulo'); ?>
    Inicio
<?php $__env->stopSection(); ?>
<?php $__env->startSection('cuerpo'); ?>
    <header class="clearfix border border-3 p-3 d-flex justify-content-around">
        <h2 class="text-center mx-auto mt-0 w-25">Gestor de afiliados
        </h2>
        <a href="<?php echo e(route('login')); ?>">
            <button class='btn bg-success bg-gradient text-white me-5' id='btnAbrirS'><strong>Iniciar sesion</strong></button>
        </a>
    </header>
<main>

</main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="/js/index.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.plantillaMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views/index.blade.php ENDPATH**/ ?>