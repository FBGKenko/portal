
<?php $__env->startSection('titulo'); ?>
    Seguimiento
<?php $__env->stopSection(); ?>
<?php $__env->startSection('cuerpo'); ?>
<header class="clearfix border border-3 p-2">
    <?php if (isset($component)) { $__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9 = $component; } ?>
<?php $component = App\View\Components\Menu::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Menu::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9)): ?>
<?php $component = $__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9; ?>
<?php unset($__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9); ?>
<?php endif; ?>
</header>
<main>
    <table class="w-75 bg-success bg-opacity-50 mx-auto mt-3 rounded rounded-3">
        <tbody>
            <tr class="bg-success bg-opacity-75">
            <th class="py-3 text-center">Compañia</th>
            <th class="py-3 text-center">Telefono</th>
            <th class="py-3 text-center">Correo</th>
            <th class="py-3 text-center">Pagina web</th>
            <th class="py-3 text-center">Acción</th>
            </tr>
            <?php for($i = 0; $i < count($empresas); $i++): ?>
                <tr class="border-bottom">
                    <td id="linkSeguir<?php echo e($i + 1); ?>" name="<?php echo e(route('mainFollow')); ?>" class="py-4 text-center fw-bold"><?php echo e($empresas[$i]->razonSocial); ?></td>
                    <td id="linkNoSeguir<?php echo e($i + 1); ?>" name="<?php echo e(route('mainUnFollow')); ?>" class="py-4 text-center"><?php echo e($empresas[$i]->telefonoEmpresa); ?></td>
                    <td class="py-4 text-center"><?php echo e($empresas[$i]->correoEmpresa); ?></td>
                    <td class="py-4 text-center"><?php echo e($empresas[$i]->paginaWeb); ?></td>
                    <td class="py-3 text-center">
                        <button id="btnPerfil<?php echo e($i + 1); ?>" class="btn bg-success bg-opacity-75 bg-gradient text-white" value="<?php echo e($empresas[$i]->id); ?>">ver perfil</button>
                        <?php if($empresas[$i]->status == 'siguiendo'): ?>

                            <button id="btnSeguir<?php echo e($i + 1); ?>" class="btn bg-success bg-gradient text-white" value="<?php echo e($empresas[$i]->id); ?>">Siguiendo</button>
                        <?php else: ?>                          
                            <button id="btnSeguir<?php echo e($i + 1); ?>" class="btn bg-success bg-opacity-75 bg-gradient text-white" value="<?php echo e($empresas[$i]->id); ?>">Seguir</button>
                        <?php endif; ?>
                    </td>                 
                </tr>   
            <?php endfor; ?>
            <?php if(count($empresas) == 0): ?>
                <tr>
                    <td colspan=99>No hay empresas registradas.</td>
                </tr>
            <?php endif; ?>  
        </tbody>
    </table>
    <div class="d-flex justify-content-center">
        <?php echo e($empresas->links()); ?>

    </div>
</main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="/js/principal.js"></script>
        <script>
            function openLeftMenu() {
                document.getElementById("leftMenu").style.display = "block";
            }

            function closeLeftMenu() {
                document.getElementById("leftMenu").style.display = "none";
            }
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('plantillas.plantillaMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views/seguimiento.blade.php ENDPATH**/ ?>