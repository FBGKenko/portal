<div>
    <form id="formPermisos" method="GET" wire:submit.prevent="submit">
        
        <div class="col-9 mx-auto mt-3 d-flex">
            <span class="fs-4">Permitir a la empresa: </span>
            <select id="cBox" class="form-select w-25 form-select-lg mb-3 mx-3" aria-label=".form-select-lg example" 
            name="empresaSelect" wire:change="cargarPermisos(document.getElementById('cBox').selectedIndex)" wire:model="comboboxEmpresa">
                <option selected value="0">Selecciona una empresa</option>
                <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($e->id); ?>"><?php echo e($e->razonSocial); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <span class="fs-4"> los siguientes datos</span>
        </div>
        <div class="border p-4 m-2 col-9 mx-auto">
            <Span class="fs-4">Compartir...</Span>
            <div>
                <div class="d-flex justify-content-center">
                    <label class="container col-auto mx-1">Datos personales
                        <input type="checkbox" id="cbDatosPersonal" wire:model="datosPersonales">
                        <span class="checkmark mt-1"></span>
                    </label>
                    <label class="container col-auto mx-1">Datos fiscales
                        <input type="checkbox" id="cbDatosFiscal" wire:model="datosFiscales">
                        <span class="checkmark mt-1"></span>
                    </label>
                    <label class="container col-auto mx-1">Datos de domicilio
                        <input type="checkbox" id="cbDatosDomicilio" wire:model="datosDomicilio">
                        <span class="checkmark mt-1"></span>
                    </label>
                    <label class="container col-auto mx-1">Datos bancarios
                        <input type="checkbox" id="cbDatosBancario" wire:model="datosBancarios">
                        <span class="checkmark mt-1"></span>
                    </label>
                </div>
            </div>
            <div class="text-center mt-5">
                <?php echo e($mensaje); ?>

                <input type="submit" class="col-auto btn btn-primary fw-bold border border-dark" id="btnPermisos" value="Cambiar permisos">
            </div>
        </div>
    </form>
</div>  
<?php /**PATH C:\laragon\www\portal\resources\views/livewire/form-permisos.blade.php ENDPATH**/ ?>