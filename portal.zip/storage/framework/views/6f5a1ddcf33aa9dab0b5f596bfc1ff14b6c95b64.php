
<?php $__env->startSection('titulo'); ?>
    Permisos
<?php $__env->stopSection(); ?>
<?php $__env->startSection('cuerpo'); ?>
<header class="clearfix border border-3 p-2">
    <?php if (isset($component)) { $__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9 = $component; } ?>
<?php $component = App\View\Components\Menu::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Menu::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9)): ?>
<?php $component = $__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9; ?>
<?php unset($__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9); ?>
<?php endif; ?>
</header>
<main>

    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('form-permisos', ['empresasSiguiendo' => $empresasSiguiendo])->html();
} elseif ($_instance->childHasBeenRendered('XcZALUN')) {
    $componentId = $_instance->getRenderedChildComponentId('XcZALUN');
    $componentTag = $_instance->getRenderedChildComponentTagName('XcZALUN');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XcZALUN');
} else {
    $response = \Livewire\Livewire::mount('form-permisos', ['empresasSiguiendo' => $empresasSiguiendo]);
    $html = $response->html();
    $_instance->logRenderedChild('XcZALUN', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="/js/principal.js"></script>
    <script src="/js/matrizPermisos.js"></script>
        <script>
            function openLeftMenu() {
                document.getElementById("leftMenu").style.display = "block";
            }

            function closeLeftMenu() {
                document.getElementById("leftMenu").style.display = "none";
            }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantillaMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\portal\resources\views/matrizPermisosDatos.blade.php ENDPATH**/ ?>