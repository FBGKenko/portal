<?php return array (
  'form-permisos' => 'App\\Http\\Livewire\\FormPermisos',
);