import React, { memo, useEffect } from 'react';
import {
    MenuBar
} from '../../components';
import { ReactComponent as OrangeDottedSquare } from '../../assets/svg/small-orange-dotted-square.svg';

const Services = memo(() => {
    useEffect(() => {
        window.scrollTo(0, 0);
    }, [])

    return (
        <div>
            <div className="w-full relative pb-12 2xl:pb-20">
                <div className="w-full bg-customBlack h-152 2xl:h-232 absolute z-20" />
                <div className="w-full bg-primary h-96 xl:h-80 2xl:h-136 absolute z-20 bottom-0" />
                <div className="py-6 md:py-14 xl:py-20 px-6 md:px-10 z-30 relative">
                    <MenuBar />

                    <div className="flex flex-col md:px-12 mt-8 md:mt-16 text-white gap-4">
                        <h2 className="uppercase text-3xl md:text-4xl lg:text-5xl xl:text-6xl 2xl:text-7xl text-center md:text-left">Services</h2>
                    </div>
                </div>

                <div className="py-3 md:py-4 md:px-20 flex flex-col z-30 relative gap-8 2xl:gap-16">
                    <div className="w-full flex flex-col">
                        <div className="px-12 md:px-0 text-white">
                            <h6 className="text-xl lg:text-2xl xl:text-3xl 2xl:text-5xl md:text-right">Buyers</h6>
                            <p className="mt-4 2xl:mt-8 md:text-right lg:text-lg xl:text-xl 2xl:text-4xl">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris consectetur sapien nec euismod luctus. Fusce consectetur elit necsem ornare, ut dapibus nisl malesuada. Vivamus ut mollis metus. Vestibulum in porta lectus. Mauris sed ex iaculis.</p>
                        </div>
                        <div
                            className="w-full mt-14 2xl:mt-32 h-52 md:h-72 xl:h-120 bg-cover bg-center rounded"
                            style={{ backgroundImage: `url('https://cdn.archilovers.com/projects/57d7daff-e586-4a1b-83b3-8d5bf0f8e070.jpg')` }}
                            alt="Service" />
                    </div>
                    <div className="w-full flex flex-col">
                        <div className="px-12 md:px-0 text-customBlack">
                            <h6 className="text-xl lg:text-2xl xl:text-3xl 2xl:text-5xl">Sellers</h6>
                            <p className="mt-4 lg:text-lg xl:text-xl 2xl:text-4xl">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris consectetur sapien nec euismod luctus. Fusce consectetur elit necsem ornare, ut dapibus nisl malesuada. Vivamus ut mollis metus. Vestibulum in porta lectus. Mauris sed ex iaculis.</p>
                        </div>
                        <div
                            className="w-full mt-14 2xl:mt-32 h-52 md:h-72 xl:h-120 bg-cover bg-center rounded"
                            style={{ backgroundImage: `url('https://cdn.archilovers.com/projects/57d7daff-e586-4a1b-83b3-8d5bf0f8e070.jpg')` }}
                            alt="Service" />
                    </div>
                    <div className="w-full flex flex-col">
                        <div className="px-12 md:px-0 text-customBlack">
                            <h6 className="text-xl lg:text-2xl xl:text-3xl 2xl:text-5xl text-right">Property Management</h6>
                            <p className="mt-4 lg:text-lg xl:text-xl 2xl:text-4xl md:text-right">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris consectetur sapien nec euismod luctus. Fusce consectetur elit necsem ornare, ut dapibus nisl malesuada. Vivamus ut mollis metus. Vestibulum in porta lectus. Mauris sed ex iaculis.</p>
                        </div>
                        <div
                            className="w-full mt-14 2xl:mt-32 h-52 md:h-72 xl:h-120 bg-cover bg-center rounded"
                            style={{ backgroundImage: `url('https://cdn.archilovers.com/projects/57d7daff-e586-4a1b-83b3-8d5bf0f8e070.jpg')` }}
                            alt="Service" />
                    </div>
                    <div className="w-full flex flex-col">
                        <div className="px-12 md:px-0 text-customBlack">
                            <h6 className="text-xl lg:text-2xl xl:text-3xl 2xl:text-5xl">Vacation Rentals</h6>
                            <p className="mt-4 lg:text-lg xl:text-xl 2xl:text-4xl">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris consectetur sapien nec euismod luctus. Fusce consectetur elit necsem ornare, ut dapibus nisl malesuada. Vivamus ut mollis metus. Vestibulum in porta lectus. Mauris sed ex iaculis.</p>
                        </div>
                    </div>
                    <div className="w-full flex flex-col">
                        <div className="px-12 md:px-0 text-customBlack">
                            <h6 className="text-xl lg:text-2xl xl:text-3xl 2xl:text-5xl">Vacation Ownership Consultants</h6>
                            <p className="mt-4 lg:text-lg xl:text-xl 2xl:text-4xl">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris consectetur sapien nec euismod luctus. Fusce consectetur elit necsem ornare, ut dapibus nisl malesuada. Vivamus ut mollis metus. Vestibulum in porta lectus. Mauris sed ex iaculis.</p>
                        </div>
                    </div>
                    <div className="w-full flex flex-col relative mt-14">
                        <OrangeDottedSquare className="-left-6 -top-5 absolute z-10" />
                        <div
                            className="w-full h-52 md:h-72 xl:h-120 bg-cover bg-center rounded z-20 relative"
                            style={{ backgroundImage: `url('https://cdn.archilovers.com/projects/57d7daff-e586-4a1b-83b3-8d5bf0f8e070.jpg')` }}
                            alt="Service" />
                        <div className="px-12 md:px-0 text-white mt-8 2xl:mt-16">
                            <h6 className="text-xl lg:text-2xl xl:text-3xl 2xl:text-5xl text-right">Property Management</h6>
                            <p className="mt-4 lg:text-lg xl:text-xl 2xl:text-4xl text-right">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris consectetur sapien nec euismod luctus. Fusce consectetur elit necsem ornare, ut dapibus nisl malesuada. Vivamus ut mollis metus. Vestibulum in porta lectus. Mauris sed ex iaculis.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div className="py-6 md:py-12 xl:py-16 2xl:py-20 px-6 md:px-20 md:px-10 flex flex-col md:flex-row justify-between items-center gap-6 sm:gap-0">
                <div className="text-2xl sm:text-3xl md:text-4xl xl:text-5xl 2xl:text-7xl text-primary text-center md:text-left">
                    <p>I'm interested</p>
                    <h4 className="capitalize">Get in touch with us</h4>
                </div>
                <button className="bg-primary shadow-lg px-20 sm:px-16 xl:px-24 2xl:px-40 py-4 sm:py-3 xl:py-5 2xl:py-7 rounded-lg text-white uppercase text-sm">Contact</button>
            </div>
        </div>
    );
});

export default Services;