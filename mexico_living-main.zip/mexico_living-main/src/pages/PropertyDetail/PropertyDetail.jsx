import React, { memo, useEffect, useContext } from 'react';
import { useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { ReactComponent as RoomsIcon } from '../../assets/svg/rooms-icon.svg';
import { ReactComponent as SurfaceIcon } from '../../assets/svg/surface-icon.svg';
import { ReactComponent as BathroomIcon } from '../../assets/svg/bathroom-icon.svg';
import { ReactComponent as ParkingIcon } from '../../assets/svg/parking-icon.svg';
import {
    MenuBar
} from '../../components';
import { LangContext, CarouselContext } from '../../context';
import { useTranslation } from '../../hooks';
import { currencyFormatter } from '../../utils';

import './PropertyDetail.css';

const PropertyDetail = memo(() => {
    const { id } = useParams();
    const { lang } = useContext(LangContext);
    const { setImages } = useContext(CarouselContext);
    const dispatch = useDispatch();
    const { propertyDetail } = useSelector((state) => state.property);
    const { t } = useTranslation();

    useEffect(() => {
        if (id) dispatch.property.getPropertyById(id);
        
        // eslint-disable-next-line
    }, [id]);

    const getSurface = (surface) => {
        if (lang === 'en') return `${surface} ft²`;

        return `${(surface/3.281).toFixed(2)} m²`;
    }

    return (
        <div className="property-detail z-40 relative">
            <div className="bg-customBlack py-6 md:py-14 xl:py-20 px-6 md:px-10 bg-customBlack">
                <MenuBar />

                <div className="flex flex-col md:px-12 mt-8 md:mt-16 text-white gap-4">
                    <div className="flex flex-col md:flex-row md:justify-between md:px-8 md:mb-4">
                        <div>
                            <h2 className="uppercase text-2xl md:text-4xl">{propertyDetail?.i18n?.find((i18n) => i18n.lang === lang)?.name}</h2>
                            <p className="hidden md:block text-2xl uppercase mt-1">{propertyDetail?.i18n?.find((i18n) => i18n.lang === lang)?.description}</p>
                        </div>

                        <p className="md:hidden uppercase">{propertyDetail?.i18n?.find((i18n) => i18n.lang === lang)?.description} ({propertyDetail?.status?.i18n?.find((i18n) => i18n.lang === lang)?.name})</p>
                        <p className="hidden md:block">
                            <span className="uppercase text-xl">{propertyDetail?.complex?.i18n?.find((i18n) => i18n.lang === lang)?.name}</span> <br />
                            <span className="text-l uppercase">{propertyDetail?.status?.i18n?.find((i18n) => i18n.lang === lang)?.name}</span>
                        </p>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-12 w-full border-t border-b border-white py-3 md:py-4 px-6 md:px-0 gap-8 md:gap-0 items-center">
                        <div className="flex flex-col gap-4 md:col-span-2 md:text-sm">
                            <p>{t('propertyDetail.ROOMS')}</p>
                            <div className="flex items-center gap-4 md:gap-2 mt-2 md:mt-0">
                                <RoomsIcon />
                                <span>{propertyDetail?.rooms}</span>
                            </div>
                        </div>
                        <div className="flex flex-col gap-4 md:col-span-2 md:text-sm">
                            <p>{t('propertyDetail.SURFACE')}</p>
                            <div className="flex items-center gap-4 md:gap-2 mt-2 md:mt-0">
                                <SurfaceIcon />
                                <span>{getSurface(propertyDetail?.surface)}</span>
                            </div>
                        </div>
                        <div className="flex flex-col gap-4 md:col-span-2 md:text-sm">
                            <p>{t('propertyDetail.BATHROOM')}</p>
                            <div className="flex items-center gap-4 md:gap-2 mt-2 md:mt-0">
                                <BathroomIcon />
                                <span>{propertyDetail?.bathrooms}</span>
                            </div>
                        </div>
                        <div className="flex flex-col gap-4 md:col-span-2 md:text-sm">
                            <p>{t('propertyDetail.PARKING')}</p>
                            <div className="flex items-center gap-4 mt-2 md:mt-0">
                                <ParkingIcon />
                                <span>{propertyDetail?.parking_spaces}</span>
                            </div>
                        </div>
                        <div className="hidden md:flex items-center col-span-4 text-2xl md:text-3xl justify-end">
                            <h6 className="">{t('propertyDetail.PRICE')} &nbsp;</h6>
                            <p className="uppercase">{currencyFormatter(propertyDetail?.price)} usd</p>
                        </div>
                    </div>

                    <div className="md:hidden">
                        <h6 className="text-lg">{t('propertyDetail.PRICE')}</h6>
                        <p className="uppercase text-4.5xl md:text-5xl mt-2">${propertyDetail?.price} usd</p>
                    </div>
                </div>
            </div>

            <div className="py-8 px-6 md:px-20 md:px-10">
                <div className="property-images grid grid-rows-4 md:grid-rows-2 grid-cols-2 md:grid-cols-4 grid-flow-row gap-4">
                    <div
                        className="row-span-2 col-span-2 rounded-lg bg-cover bg-center"
                        style={{backgroundImage: `url(${propertyDetail?.images[0]?.imageUrl})`}} />
                    <div
                        className="col-span-1 col-span-2 rounded-lg bg-cover bg-center"
                        style={{backgroundImage: `url(${propertyDetail?.images[1]?.imageUrl})`}} />
                    <div
                        className="row-span-1 col-span-1 rounded-lg bg-cover bg-center"
                        style={{backgroundImage: `url(${propertyDetail?.images[2]?.imageUrl})`}} />
                    <div
                        onClick={() => setImages(propertyDetail?.images?.map((image) => image.imageUrl))}
                        className="row-span-1 col-span-1 rounded-lg border border-black flex justify-center items-center uppercase text-center cursor-pointer" >
                        + {propertyDetail?.images?.length - 3} <br />
                        {t('propertyDetail.PHOTOS')}(s)
                    </div>
                </div>

                <div className="flex flex-col mt-16">
                    <h6 className="text-4.5xl text-center uppercase">Special amenities</h6>
                    <div className="grid grid-cols-1 md:grid-cols-3 grid-flow-row gap-4 mt-10 text-xl">
                        {propertyDetail?.amenities?.map((amenity) => (
                            <div key={`amenity${amenity.id}`} className="flex justify-center items-center gap-4 shadow rounded-lg py-6">
                                <svg width="44" height="36">       
                                    <image
                                        href={amenity?.iconUrl}
                                        src="https://mexicoliving-bucket.s3.amazonaws.com/amenities-icons/furnished-icon.svg"
                                        width="44"
                                        height="36" />    
                                </svg>
                                <p>{amenity?.i18n?.find(i18n => i18n.lang === lang).name}</p>
                            </div>
                        ))}
                    </div>
                </div>

            </div>
            <div className="get-in-touch py-6 md:py-12 xl:py-16 2xl:py-20 px-6 md:px-20 md:px-10 flex flex-col md:flex-row justify-between items-center gap-6 sm:gap-0">
                <div className="text-2xl sm:text-3xl md:text-4xl xl:text-5xl 2xl:text-7xl text-primary text-center md:text-left">
                    <p>I'm interested</p>
                    <h4 className="capitalize">Get in touch with us</h4>
                </div>
                <button className="bg-primary shadow-lg px-20 sm:px-16 xl:px-24 2xl:px-40 py-4 sm:py-3 xl:py-5 2xl:py-7 rounded-lg text-white uppercase text-sm focus:outline-none">Contact</button>
            </div>
        </div>
    );
});

export default PropertyDetail;