import React, { memo } from 'react';

import {
    Welcome,
    FeaturedProperties,
    FillingScreen,
    ExploreDestinations,
    Contact,
    Team,
    Testimonials
} from '../components';

const Main = memo(() => {
    return (
        <>
            <Welcome />

            <FeaturedProperties />

            <FillingScreen />

            <ExploreDestinations />

            <Contact />

            <Team />

            <Testimonials />
        </>
    );
});

export default Main;