export { default as Destinations } from './Destinations/Destinations';
export { default as PropertyDetail } from './PropertyDetail/PropertyDetail';
export { default as Main } from './Main';
export { default as Services } from './Services/Services';