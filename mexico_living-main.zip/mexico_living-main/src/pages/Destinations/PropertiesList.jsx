import React, { memo, useCallback, useContext } from "react";
import { useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { ReactComponent as LeftArrow } from '../../assets/svg/left-arrow.svg';
import { ReactComponent as RightArrow } from '../../assets/svg/right-arrow.svg';
import { LangContext } from '../../context';
import { useTranslation } from '../../hooks';

const PropertiesList = memo(({ setPaginationSettings, paginationSettings }) => {
    const { lang } = useContext(LangContext);
    const { properties, pagination } = useSelector((state) => state.property);
    const { t } = useTranslation();
    const history = useHistory();

    const handlePageBeforeClick = useCallback(() => {
        if (pagination.pageBefore) {
            setPaginationSettings((state) => ({ ...state, page: pagination.pageBefore }))
        }
    }, [setPaginationSettings, pagination]);

    const handleNextPageClick = useCallback(() => {
        if (pagination.nextPage) {
            setPaginationSettings((state) => ({ ...state, page: pagination.nextPage }))
        }
    }, [setPaginationSettings, pagination]);

    return (
        <div className="w-full flex flex-col">
            <div className="flex justify-between items-center text-sm lg:text-lg">
                <p>{t('destinations.PROPERTIES_COUNTER').replaceAll(':numberOfProperties', properties.length)}</p>
                <p>{t('destinations.ORDER_BY')}</p>
            </div>
            <div className="w-full grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 mt-4">
                {
                    properties.map((property, index) =>
                        <div
                            key={index}
                            onClick={() => history.push(`/property/${property.id}`)}
                            className="rounded-lg overflow-hidden shadow cursor-pointer">
                            <div
                                className="z-20 relative h-64 bg-cover bg-center"
                                style={{backgroundImage: `url(${property.mainImageUrl})`}}
                                alt="Property" />
                            <div className="w-full bg-white py-2 flex flex-col items-center rounded-lg z-30 gap-2 -mt-1 relative">
                                <p className="uppercase text-xs">{property.city.i18n.find((i18n) => i18n.lang === lang).name}</p>
                                <p className="text-primary">{property.i18n.find((i18n) => i18n.lang === lang).name}</p>
                                <p className="uppercase text-xs text-customGray">{property.i18n.find((i18n) => i18n.lang === lang).description}</p>
                                <p className="uppercase">{property.status.i18n.find((i18n) => i18n.lang === lang).name}</p>
                            </div>
                        </div>
                    )
                }
            </div>
            <div className="flex justify-between mt-8">
                <ul className="flex gap-2">
                    {Array(pagination?.totalPages || 0).fill(1).map((item, index) =>
                        <li
                            onClick={() => setPaginationSettings((state) => ({ ...state, page: index + 1 }))}
                            key={`paginationButton${index}`}
                            className={`${paginationSettings.page === index + 1 && 'bg-primary text-white'} py-1 px-3 text-sm border border-customGray hover:bg-primary hover:text-white cursor-pointer`}>{index + 1}</li>    
                    )}
                </ul>
                <div className="flex gap-2">
                    <div
                        className={`${pagination.pageBefore ? 'border-primary hover:bg-primary cursor-pointer' : 'border-customGray'} py-1 px-2 text-sm border hover:text-white flex items-center`}
                        onClick={handlePageBeforeClick}>
                        <LeftArrow />
                    </div>
                    <div
                        className={`${pagination.nextPage ? 'border-primary hover:bg-primary cursor-pointer' : 'border-customGray'} py-1 px-2 text-sm border hover:text-white flex items-center`}
                        onClick={handleNextPageClick}>
                        <RightArrow />
                    </div>
                </div>
            </div>
        </div>
    );
});

export default PropertiesList;