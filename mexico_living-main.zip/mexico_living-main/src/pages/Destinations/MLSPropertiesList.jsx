import React, { memo } from "react";

const MLSPropertiesList = memo(() => {
    return (
        <div className="px-6 md:px-20 pt-4 pb-20 flex flex-col">
            Aqui colocaremos las propiedades de la mls
        </div>
    );
});

export default MLSPropertiesList;