import React, { memo, useContext, useCallback, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import {
    MenuItem,
    TextField,
    Select,
    FormControl,
    InputLabel
} from '@material-ui/core';
import { LangContext } from '../../context';
import { useForm, Controller } from 'react-hook-form';
import * as yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { useTranslation } from '../../hooks';

const formSchema = yup.object().shape({
    cityId: yup.string(),
    statusId: yup.string(),
    budget: yup.number(),
});

const DestinationSearch = memo(({ setPaginationSettings }) => {
    const { lang } = useContext(LangContext);
    const { propertyStatuses } = useSelector((state) => state.property);
    const { defaultFormParams } = useSelector((state) => state.destinations);
    const cities = useSelector((state) => state.cities);
    const { handleSubmit, register, control } = useForm({ resolver: yupResolver(formSchema), mode: 'all' });
    const { t } = useTranslation();
    const dispatch = useDispatch();

    const onSubmit = useCallback((values) => {
        setPaginationSettings((state) => ({...state, ...values}))
    }, [setPaginationSettings])

    useEffect(() => {
        return () => {
            dispatch.destinations.setDefaultFormParams(null);
        }
        // eslint-disable-next-line
    }, []);

    console.log(propertyStatuses, defaultFormParams)

    return (
        <form
            onSubmit={handleSubmit(onSubmit)}
            className="w-full md:px-12 mt-10 md:mt-20 flex flex-col gap-6">
            <h2 className="uppercase text-white text-2xl md:text-4xl lg:text-6xl text-center md:text-left">{t('destinations.MAIN_MESSAGE')}</h2>
            <div className="flex flex-col md:flex-row gap-4">
                <FormControl variant="filled" className="md:w-2/6">
                    <InputLabel id="city">{t('destinations.SELECT_CITY')}</InputLabel>
                    <Controller
                        as={
                            <Select
                                className="rounded-lg"
                                labelId="city"
                                id="city">
                                <MenuItem value="">
                                    <em>{t('general.ALL')}</em>
                                </MenuItem>
                                {cities.map((city) => <MenuItem key={`status${city.id}`} value={city.id}>{city.i18n.find((item) => item.lang === lang).name}</MenuItem>)}
                            </Select>
                        }
                        control={control}
                        name="cityId"
                        defaultValue={defaultFormParams?.cityId} />
                </FormControl>
                <FormControl variant="filled" className="md:w-2/6">
                    <InputLabel id="type">{t('destinations.PROPERTY_TYPE')}</InputLabel>
                    <Controller
                        as={
                            <Select
                                labelId="type"
                                id="type"
                                inputRef={register}>
                                <MenuItem value="">
                                    <em>{t('general.ALL')}</em>
                                </MenuItem>
                                {propertyStatuses.map((status) => <MenuItem key={`status${status.id}`} value={status.id}>{status.i18n.find((item) => item.lang === lang).name}</MenuItem>)}
                            </Select>
                        }
                        control={control}
                        name="statusId"
                        defaultValue={defaultFormParams?.type} />
                </FormControl>
                <TextField
                    name="budget"
                    label={t('destinations.BUDGET')}
                    variant="filled"
                    className="rounded-lg md:w-1/6"
                    inputRef={register}
                    defaultValue={0} />
                <button
                    type="submit"
                    className="py-3 md:py-0 md:w-1/6 focus:outline-none bg-primary rounded-lg text-white">
                    {t('destinations.APPLY').toUpperCase()}
                </button>
            </div>
        </form>
    )
});

export default DestinationSearch;