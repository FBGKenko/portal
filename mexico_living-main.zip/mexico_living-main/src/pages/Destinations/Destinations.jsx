import React, { memo, useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
    FeaturedProperties,
    Newsletter,
    MenuBar
} from '../../components';
import { useTranslation } from '../../hooks';
import DestinationSearch from './DestinationsSearch';
import PropertiesList from './PropertiesList';
import MLSPropertiesList from './MLSPropertiesList';

import './Destinations.css';

const TYPE_OF_PROPERTIES = {
    MLS: 'mls',
    EXCLUSIVE: 'exclusive',
};

const Destinations = memo(() => {
    const dispatch = useDispatch();
    const { defaultFormParams } = useSelector((state) => state?.destinations);
    const [paginationSettings, setPaginationSettings] = useState({
        page: 1,
        orderBy: 'rooms',
        orderDirection: 'asc',
        cityId: null,
        budget: null,
        statusId: defaultFormParams?.type || null,
    });
    const [typeOfProperties, setTypeOfProperties] = useState(TYPE_OF_PROPERTIES.EXCLUSIVE);
    const { t } = useTranslation();

    useEffect(() => {
        dispatch.property.getPaginatedProperties(paginationSettings);
        // eslint-disable-next-line
    }, [paginationSettings]);

    useEffect(() => {
        window.scrollTo(0, 0);
        dispatch.property.getPropertyStatuses();
        dispatch.cities.getCities();
        // eslint-disable-next-line
    }, []);

    return (
        <div className="destinations z-40 relative">
            <div className="bg-customBlack py-6 md:py-14 xl:py-20 px-6 md:px-10 bg-customBlack z-20 relative">
                <MenuBar />

                <DestinationSearch
                    setPaginationSettings={setPaginationSettings} />
            </div>
            
            <div className="px-6 md:px-20 pt-4 pb-20 flex flex-col">
                <div className="flex justify-center uppercase gap-4 lg:text-lg">
                    <p
                        className={`${typeOfProperties === TYPE_OF_PROPERTIES.EXCLUSIVE && 'border-primary'} py-3 cursor-pointer border-b-4 border-transparent hover:border-primary`}
                        onClick={() => setTypeOfProperties(TYPE_OF_PROPERTIES.EXCLUSIVE)}>{t('destinations.EXLUSIVE_PROPERTIES_LABEL')}</p>
                    <p
                        className={`${typeOfProperties === TYPE_OF_PROPERTIES.MLS && 'border-primary'} py-3 cursor-pointer border-b-4 border-transparent hover:border-primary`}
                        onClick={() => setTypeOfProperties(TYPE_OF_PROPERTIES.MLS)}>{t('destinations.MLS_PROPERTIES_LABEL')}</p>
                </div>

                {typeOfProperties === TYPE_OF_PROPERTIES.EXCLUSIVE
                    ? <PropertiesList
                        paginationSettings={paginationSettings}
                        setPaginationSettings={setPaginationSettings} />
                    : <MLSPropertiesList />}
            </div>

            <FeaturedProperties />

            <Newsletter />
        </div>
    );
});

export default Destinations;