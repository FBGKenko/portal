const langs = {
    ES: 'es',
    EN: 'en'
};

export default langs;