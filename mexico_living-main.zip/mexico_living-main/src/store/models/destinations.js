export const destinations = {
    state: {
        defaultFormParams: null
    },
    reducers: {
        setDefaultFormParams(state, payload) {
            return {
                ...state,
                defaultFormParams: payload
            }
        }
    }
}