import { getCities } from '../../services';

export const cities = {
    state: [],
    reducers: {
        setCities(state, payload) {
            return payload;
        }
    },
    effects: (dispatch) => ({
        async getCities(payload, rootState) {
            const { data } = await getCities();
            dispatch.cities.setCities(data);
        }
    })
}