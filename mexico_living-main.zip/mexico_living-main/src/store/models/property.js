import { getPaginatedProperties, getPropertyById, getPropertyStatuses, getHightlightedProperties, getRandomProperties } from '../../services'; 

export const property = {
    state: {
        properties: [],
        pagination: {},
        propertyStatuses: [],
        propertyDetail: null,
        hightlightedProperties: [],
    },
    reducers: {
        setPropertyStatuses(state, payload) {
            return {
                ...state,
                propertyStatuses: payload
            }
        },
        setPaginatedProperties(state, payload) {
            return {
                ...state,
                properties: payload.items,
                pagination: payload.pagination,
            }
        },
        setPropertyDetail(state, payload) {
            return {
                ...state,
                propertyDetail: payload
            }
        },
        setHightlightedProperties(state, payload) {
            return {
                ...state,
                hightlightedProperties: payload
            }
        },
    },
    effects: (dispatch) => ({
        async getPropertyStatuses(payload, rootState) {
            const { data } = await getPropertyStatuses();
            dispatch.property.setPropertyStatuses(data);
        },
        async getPaginatedProperties(payload, rootState) {
            const { data } = await getPaginatedProperties({ ...payload });
            dispatch.property.setPaginatedProperties({ ...data });
        },
        async getPropertyById(payload, rootState) {
            const { data } = await getPropertyById(payload);
            dispatch.property.setPropertyDetail(data);
        },
        async getHightlightedProperties(payload, rootState) {
            const { data } = await getHightlightedProperties();
            dispatch.property.setHightlightedProperties(data);
        },
        async getRandomProperties(payload, rootState) {
            const { data } = await getRandomProperties(payload);
            dispatch.property.setHightlightedProperties(data);
        }
    })
};