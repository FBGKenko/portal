import axios from 'axios';

const BASE_URL = 'https://mexicolivingbackend.tk/properties/';

export const getPropertyStatuses = () => {
    return axios.get(`${BASE_URL}statuses`);
};

export const getCities = () => {
    return axios.get(`${BASE_URL}cities`);
}

// = { cityId, statusId, budget, page: 1, orderBy: 'rooms', orderDirection: 'asc' }
export const getPaginatedProperties = (params) => {
    let url = `${BASE_URL}all`;

    Object.keys(params).forEach((paramKey, index) => {
        if (params[paramKey] !== null) {
            url += `${index === 0 ? '?' : '&'}${paramKey}=${params[paramKey]}`
        }
    })

    return axios.get(url);
}

export const getPropertyById = (id) => {
    return axios.get(`${BASE_URL}detail/${id}`);
}

export const getHightlightedProperties = () => {
    return axios.get(`${BASE_URL}hightlighted`);
}

export const getRandomProperties = (propertiesToAvoid = []) => {
    return axios.post(
        `${BASE_URL}random`,
        { propertiesToAvoid }    
    );
}