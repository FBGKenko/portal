import axios from "axios"

const BASE_URL = 'https://mexicolivingbackend.tk/'; // Need to change this to the new backend url

export const newsletterSubscribe = ({ fullname, email }) => {
    return axios.post(
        `${BASE_URL}subscribe-newsletter`,
        {
           fullname,
           email 
        }
    );
}

export const contact = ({ fullname, email, type, readyToPurchase, justExploring, budget }) => {
    return axios.post(
        `${BASE_URL}contact`,
        {
           fullname,
           email,
           type,
           readyToPurchase,
           justExploring,
           budget
        }
    );
}