import React from 'react';
import { Switch, Route, Redirect } from 'react-router-dom';
// import { UIContext } from './context';

import {
  SocialBar,
  CustomHeader,
  Footer
} from './components';

import {
  Main,
  Destinations,
  PropertyDetail,
  Services
} from './pages';

import './assets/styles/index.css';
import './assets/styles/tailwind.css';

function App() {
  // const { isMenuOpen } = useContext(UIContext);

  return (
    <div className={`App h-screen`}>
      <header className="md:absolute w-full">
        <div className="relative">
          <SocialBar />
          <CustomHeader />
        </div>
      </header>

      <Switch>
        <Route exact path="/" component={Main} />
        <Route exact path="/destinations" component={Destinations} />
        <Route exact path="/property/:id" component={PropertyDetail} />
        <Route exact path="/services" component={Services} />

        <Redirect to="/" />
      </Switch>
      
      <Footer />
    </div>
  );
}

export default App;
