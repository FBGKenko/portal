import React, { createContext, useState } from 'react';
import { Langs } from '../enums';

export const defaultLang = Langs.ES;

export const LangContext = createContext({});

export const LangProvider = ({ children }) => {
    const [lang, setLang] = useState(defaultLang);

    return <LangContext.Provider value={{lang, setLang}}>{children}</LangContext.Provider>
};