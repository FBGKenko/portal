import React, { createContext, useState, useMemo, useEffect } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react/swiper-react';
import { Navigation, Pagination, Zoom } from 'swiper';
import { ReactComponent as CloseIcon } from '../assets/svg/close.svg';

import 'swiper/swiper-bundle.min.css';

export const CarouselContext = createContext({});

export const CarouselProvider = ({ children }) => {
    const [images, setImages] = useState([]);

    const slides = useMemo(() => {
            return (
                images.map((image, i) =>
                    <SwiperSlide zoom key={`swiper-slide-${i}`} tab="li">
                        <img
                            alt={`Carousel ${i}`}
                            src={image}
                            style={{listStyle: 'none', width: "100%", height: "auto"}} />
                    </SwiperSlide>
                )
            );
        },
        [images]
    );

    useEffect(() => {
        const bodyEl = document.querySelector('body');
        bodyEl.style.overflow = images.length ? 'hidden' : 'auto';            
    }, [images]);

    return (
        <CarouselContext.Provider value={{ images, setImages }}>
            <div className={`${images.length === 0 && 'hidden'} carousel-bg w-screen h-screen z-50 text-white flex justify-center items-center fixed`}>
                <CloseIcon
                    onClick={() => setImages([])}
                    className="absolute top-10 right-10 cursor-pointer" />
                <div className="swiper-custom-wrapper">
                    <Swiper
                        modules={[Navigation, Pagination, Zoom]}
                        slidesPerView={1}
                        navigation
                        onSlideChange={() => console.log('slide change')}
                        onSwiper={(swiper) => console.log(swiper)}>
                        {slides}
                    </Swiper>
                </div>
            </div>

            {children}
        </CarouselContext.Provider>
    );
}