const strings = {
    general: {
        CONTACT_US: 'Contact us',
        ALL: 'All',
    },
    errors: {
        REQUIRED: 'Required field'
    },
    welcome: {
        MAIN_MESSAGE: 'Total trust when buying, selling or renting',
        SECONDARY_MESSAGE: 'Mexico Living Real Estate is a full service real estate firm, offering the best that Mexico has to offer',
        WHAT_ARE_YOU_LOOKING_FOR: 'What are you looking for',
        BUY: 'Buy',
        SELL: 'Sell',
        RENT: 'Rent',
        SELECT_CITY: 'Select a city',
        SEND_REQUEST: 'Search'
    },
    menu: {
        HOME: 'Home',
        DESTINATIONS: 'Destinations',
        SERVICES: 'Services',
        CONTACT: 'Contact',
        CLOSE_MENU_TEXT: 'Close'
    },
    destinations: {
        MAIN_MESSAGE: 'Destinations & properties',
        SELECT_CITY: 'Select a city',
        PROPERTY_TYPE: 'Type',
        BUDGET: 'Budget',
        APPLY: 'Apply',
        PROPERTIES_COUNTER: ':numberOfProperties properties',
        ORDER_BY: 'Order by:',
        EXLUSIVE_PROPERTIES_LABEL: 'Exclusive',
        MLS_PROPERTIES_LABEL: 'MLS',
    },
    featured_properties: {
        MAIN_MESSAGE: 'Featured properties',
    },
    banner: {
        MAIN_MESSAGE: 'with Mexico Living our clients can not only acquire a real estate property seamlessly and with ease of mind, but also gain access the lifestyle that best suits them.',
    },
    exploreOurDestinations: {
        MAIN_MESSAGE: 'Explore our destinations',
    },
    newsletter: {
        SECONDARY_MESSAGE: 'Mexico living real estate',
        SUBSCRIBE_FOR_OUR: 'Subscribe for our',
        NEWSLETTER: 'Newsletter',
        FULL_NAME_LABEL: 'Full name*',
        EMAIL_LABEL: 'Email*',
        SEND: 'Send',
        SENDING: 'Sending...',
        EMAIL_SUCCESS_MESSAGE: 'Thank you for suscribing!',
    },
    contact: {
        SECONDARY_MESSAGE: 'Contact us',
        SUBSCRIBE_FOR_OUR: 'We want to hear from you',
        FORM_TITLE: 'Please let us help you by understanding your needs by responding to the following questions:',
        FORM_QUESTION_1: 'About you',
        FORM_QUESTION_2: 'Are you looking for an investment, partial (vacation/rental) and/or a retirement property?',
        FORM_QUESTION_2_OPTION_1: 'Investment',
        FORM_QUESTION_2_OPTION_2: 'Partial (vacation, rental)',
        FORM_QUESTION_2_OPTION_3: 'Retirement property',
        FORM_QUESTION_3: 'Are you ready to make a decision on your posible purchase?',
        FORM_QUESTION_3_OPTION_1: 'Yes',
        FORM_QUESTION_3_OPTION_2: 'No',
        FORM_QUESTION_4: 'Are you just exploring options?',
        FORM_QUESTION_4_OPTION_1: 'Yes',
        FORM_QUESTION_4_OPTION_2: 'No',
        FORM_QUESTION_5: 'Do you have a budget in mind?',
        FULL_NAME_LABEL: 'Fullname*',
        EMAIL_LABEL: 'Email*',
        SEND: 'Send',
        SENDING: 'Sending...',
        EMAIL_SUCCESS_MESSAGE: 'Thank you, we will get in touch with you shortly!',
        CALL: 'Call',
        WRITE: 'Write',
    },
    team: {
        MAIN_MESSAGE: 'Meet the team',
        VACATION_RENTAL_TAB: 'Vacation rental',
        PROPERTY_MANAGEMENT_TAB: 'Property management',
        REAL_ESTATE_TAB: 'Real estate',
    },
    testimonials: {
        MAIN_MESSAGE: 'Testimonials',
    },
    propertyDetail: {
        FOR_STATUS: 'For :propertyStatus',
        ROOMS: 'Rooms',
        SURFACE: 'Surface',
        BATHROOM: 'Bathroom',
        PARKING: 'Parking',
        PRICE: 'Price',
        PHOTOS: 'Photo'
    },
    footer: {
        HOME: 'Home',
        DESTINATIONS: 'Destinations',
        SERVICES: 'Services',
        COPYRIGHT_MESSAGE: '© Copyright 2021 México Living Real Estate. All rights reserved.',
        TERMS_AND_CONDITIONS: 'Terms and Conditions',
    }
}

export default strings;