export { default as ESStrings } from  './es';
export { default as ENStrings } from  './en';