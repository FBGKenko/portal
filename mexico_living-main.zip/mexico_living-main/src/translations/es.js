const strings = {
    general: {
        CONTACT_US: 'Contactanos',
        ALL: 'Todos'
    },
    errors: {
        REQUIRED: 'Campo requerido'
    },
    welcome: {
        MAIN_MESSAGE: 'Confianza total al comprar, vender o rentar',
        SECONDARY_MESSAGE: 'Mexico Living Real Estate es una firma de bienes raíces de servicio completo, que ofrece lo mejor en México.',
        WHAT_ARE_YOU_LOOKING_FOR: '¿Qué estas buscando?',
        SEND_REQUEST: 'Buscar',
        BUY: 'Comprar',
        SELL: 'Venta',
        RENT: 'Renta',
        SELECT_CITY: 'Selecciona una ciudad',
    },
    menu: {
        HOME: 'Inicio',
        DESTINATIONS: 'Destinos',
        SERVICES: 'Servicios',
        CONTACT: 'Contacto',
        CLOSE_MENU_TEXT: 'Cerrar'
    },
    destinations: {
        MAIN_MESSAGE: 'Destinos y propiedades',
        SELECT_CITY: 'Selecciona una cuidad',
        PROPERTY_TYPE: 'Tipo',
        BUDGET: 'Presupuesto',
        APPLY: 'Aplicar',
        PROPERTIES_COUNTER: ':numberOfProperties propiedades',
        ORDER_BY: 'Ordenar por:',
        EXLUSIVE_PROPERTIES_LABEL: 'Exclusivas',
        MLS_PROPERTIES_LABEL: 'MLS',
    },
    featured_properties: {
        MAIN_MESSAGE: 'Propiedades destacadas',
    },
    banner: {
        MAIN_MESSAGE: 'con Mexico Living nuestros clientes no solo pueden adquirir una propiedad inmobiliaria sin problemas y con tranquilidad, sino también acceden al estilo de vida que mejor se adapte a ellos.',
    },
    exploreOurDestinations: {
        MAIN_MESSAGE: 'Explora nuestros destinos',
    },
    newsletter: {
        SECONDARY_MESSAGE: 'Mexico living real estate',
        SUBSCRIBE_FOR_OUR: 'Subscribete a nuestro',
        NEWSLETTER: 'Boletín',
        FULL_NAME_LABEL: 'Nombre completo*',
        EMAIL_LABEL: 'Correo*',
        SEND: 'Envíar',
        SENDING: 'Enviando...',
        EMAIL_SUCCESS_MESSAGE: 'Gracias por suscribirte!',
    },
    contact: {
        SECONDARY_MESSAGE: 'Contactanos',
        MAIN_MESSAGE: 'Queremos escucharte',
        FORM_TITLE: 'Por favor dejanos ayudarte, responde las siguientes preguntas para poder entender tus necesidades:',
        FORM_QUESTION_1: 'Acerca de tí',
        FORM_QUESTION_2: '¿Está buscando una propiedad de inversión, parcial (vacaciones/alquiler) y/o de retiro?',
        FORM_QUESTION_2_OPTION_1: 'Inversión',
        FORM_QUESTION_2_OPTION_2: 'Parcial (vacaciones, alquiler)',
        FORM_QUESTION_2_OPTION_3: 'Propiedad de retiro',
        FORM_QUESTION_3: '¿Estás listo(a) para tomar una decisión sobre tu posible compra?',
        FORM_QUESTION_3_OPTION_1: 'Si',
        FORM_QUESTION_3_OPTION_2: 'No',
        FORM_QUESTION_4: '¿Estás explorando opciones?',
        FORM_QUESTION_4_OPTION_1: 'Si',
        FORM_QUESTION_4_OPTION_2: 'No',
        FORM_QUESTION_5: '¿Tienes un presupuesto en mente?',
        FULL_NAME_LABEL: 'Nombre completo*',
        EMAIL_LABEL: 'Correo*',
        SEND: 'Envíar',
        SENDING: 'Enviando...',
        EMAIL_SUCCESS_MESSAGE: 'Gracias por escribirnos, en breve nos pondremos en contacto contigo!',
        CALL: 'Llamanos',
        WRITE: 'Escribenos',
    },
    team: {
        MAIN_MESSAGE: 'Conoce nuestro equipo',
        VACATION_RENTAL_TAB: 'Rentas vacacionales',
        PROPERTY_MANAGEMENT_TAB: 'Administración de propiedades',
        REAL_ESTATE_TAB: 'Bienes raíces',
    },
    testimonials: {
        MAIN_MESSAGE: 'Testimonios',
    },
    propertyDetail: {
        FOR_STATUS: ':propertyStatus',
        ROOMS: 'Habitaciones',
        SURFACE: 'Superficie',
        BATHROOM: 'Baños',
        PARKING: 'Estacionamiento',
        PRICE: 'Precio',
        PHOTOS: 'Foto'
    },
    footer: {
        HOME: 'Inicio',
        DESTINATIONS: 'Destinos',
        SERVICES: 'Servicios',
        COPYRIGHT_MESSAGE: '© Copyright 2021 México Living Real Estate. Todos los derechos reservados.',
        TERMS_AND_CONDITIONS: 'Terminos y condiciones',
    }
}

export default strings;