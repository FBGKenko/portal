import React, { memo } from 'react';
import { useTranslation } from '../../hooks';

const Team = memo(() => {
    const { t } = useTranslation();
    
    return (
        <div className="explore-destinations w-full pt-8 pb-20 relative border-b border-customGray">
            <div className="w-full px-6 sm:px-16 md:px-28">
                <h3 className="text-5xl flex items-center mt-4 text-customBlack text-primary">
                    {t('team.MAIN_MESSAGE')}
                </h3>

                <ul className="flex flex-col md:flex-row items-start uppercase mt-8 text-sm gap-4">
                    <li className="text-customBlack hover:text-primary md:pr-4 pb-2 cursor-pointer">{t('team.REAL_ESTATE_TAB')}</li>
                    <li className="text-customBlack hover:text-primary md:pr-4 pb-2 cursor-pointer">{t('team.VACATION_RENTAL_TAB')}</li>
                    <li className="text-customBlack hover:text-primary md:pr-4 pb-2 cursor-pointer">{t('team.PROPERTY_MANAGEMENT_TAB')}</li>
                </ul>

                <div class="grid gap-10 grid-cols-3 mt-8">
                    {[1,2,3].map(item => (
                        <div className="p-6 bg-blue flex items-center shadow-lg rounded-lg">
                            <img
                                src="https://picsum.photos/65"
                                alt="Prueba"
                                className="rounded-full" />
                            <div className="ml-4">
                                <p className="mt-4 uppercase font-semibold text-primary">Team member name</p>
                                <span>-CEO</span>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
});

export default Team;