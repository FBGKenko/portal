import React, { memo } from 'react';
import { useTranslation } from '../../hooks';
import { ReactComponent as Logo } from '../../assets/svg/logo.svg';
import { ReactComponent as OrangeWave } from '../../assets/svg/orange-wave.svg';
import { ReactComponent as OrangeWaveXL } from '../../assets/svg/orange-wave-xl.svg';

import './FillingScreen.css';

const FillingScreen = memo(() => {
    const { t } = useTranslation();

    return (
        <div className="filling-screen w-full flex justify-center items-center relative">
            <div className="w-2/3 flex flex-col justify-center items-center gap-28">
                <Logo />
                <h4 className="text-center text-lg md:text-xl text-customBlack">{t('banner.MAIN_MESSAGE')}</h4>
            </div>
    
            <OrangeWave className="absolute bottom-0 w-full xl:hidden" />
            <OrangeWaveXL className="absolute bottom-0 w-full hidden xl:block" />
        </div>
    );
});

export default FillingScreen;