import React, { memo, useCallback, useState } from 'react';
import { useTranslation } from '../../hooks';
import { newsletterSubscribe } from '../../services';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';

import './Newsletter.css';

const formSchema = yup.object().shape({
    fullname: yup.string().required('message'),
    email: yup.string().required('message'),
});

const Newsletter = memo(() => {
    const { t } = useTranslation();
    const { handleSubmit, register, errors, reset } = useForm({ resolver: yupResolver(formSchema), mode: 'all' });
    const [ isLoading, setIsLoading ] = useState(false);
    const [ showSuccessMsg, setShowSuccessMsg ] = useState(false);

    const onSubmit = useCallback((values) => {
        setIsLoading(false);
        newsletterSubscribe({ ...values })
            .then((response) => {
                reset();
                setShowSuccessMsg(true);
                setTimeout(() => setShowSuccessMsg(false), 4000);
            }).catch((error) => {
                console.error(error);
            }).then(() => setIsLoading(false));
    }, [reset, setIsLoading, setShowSuccessMsg]);

    return (
        <div className="newsletter py-10 md:py-16 lg:py-48 xl:py-64" onSubmit={handleSubmit(onSubmit)}>
            <div className="px-10 md:px-28 flex flex-col lg:flex-row justify-between gap-4">
                <div className="lg:w-1/2">
                    <span className="uppercase text-xs sm:text-sm md:text-md xl:text-2xl">{t('newsletter.SECONDARY_MESSAGE')}</span>
                    <h4 className="text-3xl md:text-6xl lg:text-7xl xl:text-8xl text-customGray">
                        {t('newsletter.SUBSCRIBE_FOR_OUR')} <br />
                        <span className="text-customBlack">{t('newsletter.NEWSLETTER')}</span>
                    </h4>
                </div>
                <form className="flex flex-col gap-6 lg:w-1/2">
                    <div className="flex flex-col">
                        <input
                            placeholder={t('newsletter.FULL_NAME_LABEL')}
                            type="text"
                            name="fullname"
                            className={`${errors.fullname ? 'border-red-500' : 'border-customGray'} p-4 rounded-lg border focus:outline-none`}
                            ref={register} />
                            {errors.fullname && <span className="text-xs text-red-500">{t('errors.REQUIRED')}</span>}
                    </div>
                    <div className="flex flex-col">
                    <input
                        placeholder={t('newsletter.EMAIL_LABEL')}
                        type="text"
                        name="email"
                        className={`${errors.email ? 'border-red-500' : 'border-customGray'} p-4 rounded-lg border focus:outline-none`}
                        ref={register} />
                        {errors.email && <span className="text-xs text-red-500">{t('errors.REQUIRED')}</span>}
                    </div>
                    {showSuccessMsg
                        ? <p className="text-xl text-primary text-center">{t('newsletter.EMAIL_SUCCESS_MESSAGE')}</p>
                        : <button
                                disabled={isLoading}
                                type="submit"
                                className="uppercase bg-primary text-white lg:w-3/5 py-3 md:py-6 rounded-lg focus:outline-none">
                                {isLoading ? t('newsletter.SENDING') : t('newsletter.SEND')}
                            </button> }
                </form>
            </div>
        </div>
    );
});

export default Newsletter;