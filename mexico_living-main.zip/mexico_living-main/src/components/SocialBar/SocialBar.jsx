import React, { memo, useContext } from 'react';
import { ReactComponent as FbIcon } from '../../assets/svg/facebook.svg';
import { ReactComponent as LinkedinIcon } from '../../assets/svg/linkedin.svg';
import { ReactComponent as InstagramIcon } from '../../assets/svg/instagram.svg';
import { ReactComponent as PhoneIcon } from '../../assets/svg/phone.svg';
import { ReactComponent as FlagUsaIcon } from '../../assets/svg/flag-usa.svg';
import { ReactComponent as CloseIcon } from '../../assets/svg/menu.svg';
import { UIContext } from '../../context';

const SocialBar = memo(() => {
    const { setIsMenuOpen } = useContext(UIContext);
    
    return (
        <>
            <Mobile setIsMenuOpen={setIsMenuOpen} />
            <Desktop />
        </>
    );
});

const Desktop = memo(() => {
    return (
        <div className="hidden md:flex social-bar bg-customBlack text-white justify-between items-center py-2 px-6 w-full shadow-lg z-50 relative">
            <div className="flex gap-4">
                <a href="https://www.facebook.com/mexicolivingrealestate" rel="noreferrer" target="_blank"><FbIcon /></a>
                <a href="https://mx.linkedin.com/company/mexico-living-real-estate" rel="noreferrer" target="_blank"><LinkedinIcon /></a>
                <a href="https://www.instagram.com/mexicolivingrealestate" rel="noreferrer" target="_blank"><InstagramIcon /></a>
            </div>
            <div className="flex text-sm gap-8">
                <p className="flex items-center gap-2">
                    <PhoneIcon />
                    +52 (624) 174 35 81
                </p>
                <p className="flex items-center gap-2">
                    <FlagUsaIcon />
                    USA - (619) 796-3994
                </p>
            </div>
        </div>
    );
})

const Mobile = memo(({setIsMenuOpen}) => {
    return (
        <div className="md:hidden bg-customBlack text-white flex justify-center py-2 px-6 w-full shadow-lg z-50 relative"> 
            <CloseIcon className="absolute left-6 cursor-pointer" onClick={() => setIsMenuOpen(true)} />
            <div className="flex gap-4">
                <a href="https://app.agentshield.com/go/29728?as=qy3w1kF0fvY%3D" rel="noreferrer" target="_blank"><FbIcon /></a>
                <a href="https://app.agentshield.com/go/29728?as=qy3w1kF0fvY%3D" rel="noreferrer" target="_blank"><LinkedinIcon /></a>
                <a href="https://app.agentshield.com/go/29728?as=qy3w1kF0fvY%3D" rel="noreferrer" target="_blank"><InstagramIcon /></a>
            </div>
        </div>
    );
})

export default SocialBar;