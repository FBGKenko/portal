import React, { memo, useContext, useState, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { ReactComponent as CloseIcon } from '../../assets/svg/close.svg';
import { ReactComponent as WhiteLogo } from '../../assets/svg/white-logo.svg';
import { ReactComponent as FbIcon } from '../../assets/svg/facebook-xl.svg';
import { ReactComponent as LinkedinIcon } from '../../assets/svg/linkedin-xl.svg';
import { ReactComponent as InstagramIcon } from '../../assets/svg/instagram-xl.svg';
import { UIContext, LangContext } from '../../context';
import { useTranslation } from '../../hooks';
import { Langs } from '../../enums';
import {
    Menu,
    MenuItem
} from '@material-ui/core';

import './CustomHeader.css';

const CustomHeader = memo(() => {
    const { isMenuOpen, setIsMenuOpen } = useContext(UIContext);
    const { lang, setLang } = useContext(LangContext);
    const [anchorEl, setAnchorEl] = useState(null);
    const { t } = useTranslation();

    const onLangChange = useCallback((value) => {
        setLang(value);
        setAnchorEl(null);
    }, [setLang, setAnchorEl]);

    return (
        <nav className={`absolute ${isMenuOpen && 'z-50'} z-0 top-0 flex justify-end items-center w-full py-6 px-12 h-screen`}>
            <div className={`menu ${isMenuOpen && 'open'} absolute w-full h-full`}>
                <div className={`${!isMenuOpen && 'invisible'} flex items-center justify-between px-10 md:px-12 py-2 md:mt-16 absolute shadow-lg md:shadow-none w-full`}>
                    <div
                        onClick={() => setIsMenuOpen(false)}
                        className="flex items-center cursor-pointer">
                        <CloseIcon />
                        <p className="text-white ml-6">{t('menu.CLOSE_MENU_TEXT')}</p>
                    </div>
                    <div>
                        <p className="text-white underline cursor-pointer" aria-controls="simple-menu" aria-haspopup="true" onClick={(e) => setAnchorEl(e.currentTarget)}>
                            {lang.toUpperCase()}
                        </p>
                        <Menu
                            id="simple-menu"
                            anchorEl={anchorEl}
                            open={Boolean(anchorEl)}
                            onClose={() => setAnchorEl(null)}>
                            <MenuItem onClick={() => onLangChange(Langs.ES)}>ES</MenuItem>
                            <MenuItem onClick={() => onLangChange(Langs.EN)}>EN</MenuItem>
                        </Menu>
                    </div>
                </div>
                <div className={`${!isMenuOpen && 'invisible'} h-screen flex flex-col justify-between items-center pb-14`}>
                    <div className="flex justify-center w-full">
                        <WhiteLogo className="mt-16 md:mt-8" />
                    </div>
                    <ul className="text-white text-4xl md:text-6xl text-center">
                        <li className="my-6 md:my-10"><Link to="/" onClick={() => setIsMenuOpen(false)}>{t('menu.HOME')}</Link></li>
                        <li className="my-6 md:my-10"><Link to="/destinations" onClick={() => setIsMenuOpen(false)}>{t('menu.DESTINATIONS')}</Link></li>
                        <li className="my-6 md:my-10"><Link to="/services" onClick={() => setIsMenuOpen(false)}>{t('menu.SERVICES')}</Link></li>
                    </ul>
                    <div className="flex flex-col md:flex-row items-between justify-center md:justify-between md:items-end w-full px-12">
                        <div className="text-white text-sm text-center md:text-left flex-1">
                            <h4 className="text-primary text-xl mb-4">{t('menu.CONTACT')}</h4>

                            <p className="my-2">+52 1 (624) 174 35 81</p>
                            <p className="my-2">USA - 1 (619) 796-3994</p>
                            <p className="mt-2">mexicoliving@gmail.com</p>
                        </div>
                        <div className="flex justify-center gap-20 mt-8 md:mt-0 flex-1">
                            <a href="https://www.facebook.com/mexicolivingrealestate" rel="noreferrer" target="_blank"><FbIcon /></a>
                            <a href="https://mx.linkedin.com/company/mexico-living-real-estate" rel="noreferrer" target="_blank"><LinkedinIcon /></a>
                            <a href="https://www.instagram.com/mexicolivingrealestate" rel="noreferrer" target="_blank"><InstagramIcon /></a>
                        </div>
                        <div className="hidden md:block md:invisible flex-1">hidden</div>
                    </div>
                </div>
            </div>
        </nav>
    );
});

export default CustomHeader;