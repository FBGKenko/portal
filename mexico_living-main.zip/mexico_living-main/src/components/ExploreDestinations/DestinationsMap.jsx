import { memo } from "react";
import { GoogleMap, Marker, withGoogleMap, withScriptjs } from 'react-google-maps';

const DestinationMap = memo(withScriptjs(withGoogleMap((props) => {
    return (
        <GoogleMap
            defaultZoom={8}
            defaultCenter={{ lat: -109.9538667, lng: 22.8829279 }}
        >
            <Marker position={{ lat: -109.9608485, lng: 22.893996 }} />
            <Marker position={{ lat: -109.9538667, lng: 22.8829279 }} />
        </GoogleMap>
    );
})));

export default DestinationMap;