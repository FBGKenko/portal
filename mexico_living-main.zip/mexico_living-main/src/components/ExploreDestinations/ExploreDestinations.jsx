import React, { memo } from 'react';
import DestinationMap from './DestinationsMap';
import { useTranslation } from '../../hooks';

import './ExploreDestinations.css';

const ExploreDestinations = memo(() => {
    // const [housesCardHeaderHeight, setHousesCardHeaderHeight] = useState(0);
    const { t } = useTranslation();

    return (
        <div className="explore-destinations w-full pt-8 pb-20 relative overflow-x-hidden">
            <div className="w-full md:px-28">
                <div className="flex justify-between items-end px-8 md:px-0">
                    <div>
                        <p className="text-md uppercase">Mexico living real estate</p>
                        <h3 className="text-primary text-5xl flex items-center mt-4 max-w-md">
                            {t('exploreOurDestinations.MAIN_MESSAGE')}
                        </h3>
                    </div>
                </div>
                
                <div className="mt-8">
                    <DestinationMap
                        googleMapURL="https://maps.googleapis.com/maps/api/js?key=AIzaSyDEI0Yna-kAIrFdgjVLBe0so8qxDpbiGBA&v=3.exp&libraries=geometry,drawing,places"
                        loadingElement={<div style={{ height: `100%` }} />}
                        containerElement={<div style={{ height: `400px` }} />}
                        mapElement={<div style={{ height: `100%` }} />} />
                </div>
            </div>
        </div>
    );
});

/**
 * <div className="flex flex-col lg:flex-row w-full gap-10 mt-14 relative">
                    <DottedSquare className="absolute -bottom-1 md:-bottom-12 -right-32 md:-right-12 z-10" />

                    <div className="shadow-md bg-white rounded-lg overflow-hidden w-full lg:w-1/2">
                        <img src="https://cdn.archilovers.com/projects/57d7daff-e586-4a1b-83b3-8d5bf0f8e070.jpg" alt="House" className="z-10"/>
                        <div className="py-4 px-7 flex flex-col -mt-1 z-20 rounded-md">
                            <p className="text-3xl text-customBlack">Riviera Maya</p>
                            <p className="text-xs text-customGray">Yucatán, Mexico</p>
                            <h6 className="text-lg text-primary mt-6">10 properties</h6>
                        </div>
                    </div>

                    <div className="shadow-md bg-white rounded-lg overflow-hidden lg:w-1/2 z-20">
                        <div className="py-4 px-8 border-b border-customGray" id="header-container">
                            <div className="flex justify-between items-center">
                                <p className="text-3xl">Cabo San Lucas</p>
                                <CloseIcon />
                            </div>
                            <p className="text-sm text-customGray">Baja California Sur, Mexico</p>
                        </div>
                        <div className="flex p-6 text-primary underline text-lg" style={{height: `calc(100% - ${housesCardHeaderHeight}px)`}}>
                            <ul className="w-1/2 h-full">
                                <li className="h-1/9">Quivira</li>
                                <li className="h-1/9">Tramonti</li>
                                <li className="h-1/9">Cabo Escondido</li>
                                <li className="h-1/9">Casa Adobe</li>
                                <li className="h-1/9">San Jose del Cabo</li>
                                <li className="h-1/9">La Paz</li>
                                <li className="h-1/9">Loreto</li>
                                <li className="h-1/9">Todos Santos</li>
                                <li className="h-1/9">Pescadero</li>
                            </ul>
                            <ul className="w-1/2">
                                <li>Cerritos</li>
                                <li>Cabo del Este</li>
                                <li>Barriles</li>
                                <li>Constitucion</li>
                            </ul>
                        </div>
                    </div>
                    <div className="px-20 z-20 block md:hidden">
                        <button className="view-all-btn border-primary border flex-grow-0 text-primary px-8 py-3 rounded-lg w-full">View all destinations</button>
                    </div>
                </div>
 */

export default ExploreDestinations;