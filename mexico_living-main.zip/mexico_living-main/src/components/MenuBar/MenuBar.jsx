import React, { memo, useState, useContext, useCallback } from 'react';
import { ReactComponent as MenuIcon } from '../../assets/svg/menu.svg';
import { ReactComponent as WhiteLogo } from '../../assets/svg/white-logo.svg';
import {
    Menu,
    MenuItem
} from '@material-ui/core';
import { UIContext, LangContext } from '../../context';
import { Langs } from '../../enums';
import { useTranslation } from '../../hooks';

const MenuBar = memo(() => {
    const [anchorEl, setAnchorEl] = useState(null);
    const { setIsMenuOpen } = useContext(UIContext);
    const { lang, setLang } = useContext(LangContext);
    const { t } = useTranslation();

    const langMenuClick = useCallback((value) => {
        setLang(value);
        setAnchorEl(null);
    }, [setLang, setAnchorEl]);

    return (
        <div className="w-full flex justify-between items-center z-20">
            <div className="hidden md:block flex-1">
                <MenuIcon
                    onClick={() => setIsMenuOpen(true)}
                    className="cursor-pointer" />
            </div>
            <WhiteLogo className="flex-1" />
            <div className="hidden md:flex justify-end items-center gap-4 flex-1">
                <button className="text-white bg-primary py-1.5 px-6 lg:px-14 xl:px-20 rounded-lg">{t('general.CONTACT_US')}</button>
                <div>
                    <p className="text-white underline cursor-pointer" aria-controls="simple-menu" aria-haspopup="true" onClick={(e) => setAnchorEl(e.currentTarget)}>{lang?.toUpperCase()}</p>
                    <Menu
                        id="simple-menu"
                        anchorEl={anchorEl}
                        open={Boolean(anchorEl)}
                        onClose={() => setAnchorEl(null)}>
                        <MenuItem onClick={() => langMenuClick(Langs.ES)}>ES</MenuItem>
                        <MenuItem onClick={() => langMenuClick(Langs.EN)}>EN</MenuItem>
                    </Menu>
                </div>
            </div>
        </div>
    );
});

export default MenuBar;