import React, { memo } from 'react';
import { Link } from 'react-router-dom';
import { ReactComponent as Logo } from '../../assets/svg/white-logo.svg';
import { ReactComponent as InstagramIcon } from '../../assets/svg/instagram-xl.svg';
import { ReactComponent as LinkedinIcon } from '../../assets/svg/linkedin-xl.svg';
import { ReactComponent as FbIcon } from '../../assets/svg/facebook-xl.svg';
import { useTranslation } from '../../hooks';

const Footer = memo(() => {
    const { t } = useTranslation();

    return (
        <footer className="py-10 2xl:py-20 px-6 md:px-20 md:px-10 w-full bg-primary">
            <div className="flex flex-col md:flex-row md:items-end gap-8 md:gap-14 lg:gap-28 xl:gap-60 2xl:gap-100">
                <div className="flex flex-col items-center gap-12">
                    <Logo />
                    <div className="flex gap-8">
                        <a href="https://www.facebook.com/mexicolivingrealestate" rel="noreferrer" target="_blank"><FbIcon /></a>
                        <a href="https://mx.linkedin.com/company/mexico-living-real-estate" rel="noreferrer" target="_blank"><LinkedinIcon /></a>
                        <a href="https://www.instagram.com/mexicolivingrealestate" rel="noreferrer" target="_blank"><InstagramIcon /></a>
                    </div>
                </div>
                <div className="flex flex-col text-white gap-8 lg:gap-16">
                    <ul className="flex flex-col md:flex-row text-center gap-2 md:gap-8 text-lg lg:text-sm 2xl:text-2xl md:text-base">
                        <li><Link to="/">{t('footer.HOME')}</Link></li>
                        <li><Link to="/destinations">{t('footer.DESTINATIONS')}</Link></li>
                        <li><Link to="/services">{t('footer.SERVICES')}</Link></li>
                    </ul>
                    <p className="text-center md:text-left lg:text-sm 2xl:text-2xl">{t('footer.COPYRIGHT_MESSAGE')} <u>{t('footer.TERMS_AND_CONDITIONS')}</u></p>
                </div>
            </div>
        </footer>
    );
});

export default Footer;