import React, { memo, useState } from 'react';
import { useHistory } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { ReactComponent as DottedSquare } from '../../assets/svg/dotted-square.svg';
import { ReactComponent as HouseIcon } from '../../assets/svg/house-icon.svg';
import { useTranslation } from '../../hooks';

import './FeaturedProperties.css';
import { useEffect } from 'react';
import { useSelector } from 'react-redux';

const FeaturedProperties = memo(() => {
    const history = useHistory();
    const { t, lang } = useTranslation();
    const dispatch = useDispatch();
    const { hightlightedProperties } = useSelector((st) => st.property);
    const [featuredProperties, setFeaturedProperties] = useState([]);
    
    useEffect(() => {
        if (hightlightedProperties?.length) {
            let random = Math.floor(Math.random() * (hightlightedProperties.length - 4));
            setFeaturedProperties(hightlightedProperties.slice(random, random + 4));
            setInterval(() => {
                random = Math.floor(Math.random() * (hightlightedProperties.length - 4));
                setFeaturedProperties(hightlightedProperties.slice(random, random + 4));
            }, 10000)
        }
        // eslint-disable-next-line
    }, [hightlightedProperties.length]);
    
    useEffect(() => {
        dispatch.property.getRandomProperties();
        // eslint-disable-next-line
    }, []);

    return (
        <div className="featured-properties w-full bg-primary relative md:pt-14 pb-10 md:pb-20 overflow-x-hidden">
            <DottedSquare className="absolute top-32 md:top-14 z-20" />
            <div className="w-full px-6 md:px-20 z-30 relative">
                <h3 className="text-white text-4xl md:text-5xl uppercase flex items-center" style={{height: '123px'}}>
                    {t('featured_properties.MAIN_MESSAGE')}
                </h3>
                <div className="slider-container">
                    <div className="slider-container__items grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 grid-rows-1 gap-4 md:gap-8">
                        {(featuredProperties).map((property) =>
                            <div
                                key={property.id} className="shadow-md bg-white rounded-lg overflow-hidden cursor-pointer"
                                onClick={() => history.push(`/property/${property.id}`)}>
                                <img
                                    src={property.images[0].imageUrl}
                                    alt="House"
                                    className="z-20 relative"/>
                                <div className="py-2 bg-white flex flex-col items-center gap-2 uppercase -mt-1 z-30 rounded-lg relative">
                                    <p className="text-xs text-customBlack">{property?.complex?.i18n?.find((item) => item.lang === lang)?.name}</p>
                                    <h6 className="text-sm text-primary">{property?.i18n?.find((item) => item.lang === lang)?.name}</h6>
                                    <p className="text-xs text-customGray">{property?.i18n?.find((item) => item.lang === lang)?.description}</p>
                                    <div className="flex items-center gap-3 mt-4">
                                        <HouseIcon />
                                        <p className="text-xs">{property?.status?.i18n?.find((item) => item.lang === lang)?.name}</p>
                                    </div>
                                </div>
                            </div>)}
                    </div>
                </div>
            </div>

        </div>
    );
});

/**
 <div className="slider-container__selector mt-6 md:mt-20 flex items-end gap-4 text-white">
                        <p className="text-xxs" style={{marginTop: '-.1875rem'}}>01</p>
                         <div className="flex w-full gap-2">
                            {[1,2,3,4].map((item, i) =>
                                <div className="uppercase w-1/4 text-xxs md:text-xl xl:text-2xl">
                                    <p className={`${i !== 0 && 'invisible'}`}>Baja california</p>
                                    <div className={`bg-customGray h-0.5 ${i === 0 && 'bg-white h-1.5'} w-full rounded-md`} style={{marginTop: `${i !== 0 ? 0.9375 : 0.75}rem`}} />
                                </div>)}
                         </div>
                         <p className="text-xxs">04</p>
                    </div>
 */

export default FeaturedProperties;