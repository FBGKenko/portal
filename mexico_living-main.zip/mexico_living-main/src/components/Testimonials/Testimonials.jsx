import React, { memo } from 'react';
import PeopleImg from '../../assets/img/people.jpg';
import { useTranslation } from '../../hooks';

import './Testimonials.css';

const Testimonials = memo(() => {
    const { t } = useTranslation();

    return (
        <div className="pt-8 pb-20 px-4 sm:px-12 md:px-28 w-full">
            <h3 className="text-5xl text-primary text-center w-full">{t('testimonials.MAIN_MESSAGE')}</h3>
            <div className="w-full flex flex-col md:flex-row gap-4 mt-4 md:mt-14">
                {[1, 1, 1].map(() =>
                        <div className="testimonial-card rounded-lg shadow-lg p-5 text-primary">
                            <div
                                style={{backgroundImage: `url(${PeopleImg})`}}
                                className="h-10 w-10 rounded-full bg-cover" />
                            <p className="text-sm mt-6">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut maximus congue sem in placerat. </p>
                            <p className="mt-4">@kathwills</p>
                        </div>
                    )
                }
            </div>
        </div>
    );
});

export default Testimonials;