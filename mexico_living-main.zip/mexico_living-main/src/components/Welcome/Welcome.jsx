import React, { memo, useEffect, useState } from 'react';

import './Welcome.css'

// Components
import WelcomeForm from './WelcomeForm';
import {
    MenuBar
} from '../';
import { useTranslation } from '../../hooks';

const Welcome = memo(({socialBarRef}) => {
    // eslint-disable-next-line
    const [ socialBarHeight, setSocialBarHeight ] = useState(0);
    const { t } = useTranslation();

    useEffect(() => {
        window.scrollTo(0, 0);
        const socialBar = document.getElementsByClassName('social-bar')[0];
        setSocialBarHeight(socialBar?.clientHeight || 0);
        window.addEventListener('resize', () => {
            setSocialBarHeight(socialBar?.clientHeight || 0);
        });

        return () => {
            window.removeEventListener('resize', () => {});
        };
    }, []);

    return (
        <div className="welcome w-full flex flex-col items-center text-white relative z-20">
            <div className="flex flex-col items-center pb-20 pt-16 px-10">
                <MenuBar />
                
                <div className="md:px-10 lg:px-32 xl:px-48">
                    <h1 className="text-xs lg:text-base xl:text-lg text-center mt-14 md:mt-16 text-white">{t('welcome.SECONDARY_MESSAGE')}</h1>
                    <h2 className="text-3xl md:text-4xl lg:text-5xl xl:text-7xl 2xl:text-8xl text-center uppercase mt-14 md:mt-2 text-white">{t('welcome.MAIN_MESSAGE')}</h2>
                    
                    <WelcomeForm />
                </div>
            </div>
        </div>
    );
});

export default Welcome;
