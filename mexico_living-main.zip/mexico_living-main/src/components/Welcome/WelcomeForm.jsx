import React, { memo, useCallback, useEffect, useContext } from 'react';
import { useHistory } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { useTranslation } from '../../hooks';
import { LangContext } from '../../context';
import { useForm, Controller } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import {
    FormControl,
    InputLabel,
    Select,
    MenuItem,
} from '@material-ui/core';

const formSchema = yup.object().shape({
    city: yup.string(),
    type: yup.string()
});

const WelcomeForm = memo(() => {
    const { lang } = useContext(LangContext);
    const { t } = useTranslation();
    const { handleSubmit, register, setValue, control, watch } = useForm({ resolver: yupResolver(formSchema), mode: 'all' });
    const dispatch = useDispatch();
    const cities = useSelector((state) => state.cities);
    const history = useHistory();

    const onSubmit = useCallback((data) => {
        dispatch.destinations.setDefaultFormParams({ ...data })
        history.push(`/destinations`);
    }, [history, dispatch]);

    useEffect(() => {
        dispatch.cities.getCities();
        dispatch.property.getPropertyStatuses();
        // eslint-disable-next-line
    }, []);

    return (
        <form onSubmit={handleSubmit(onSubmit)} className="w-full">
            <p className="text-xl lg:text-2xl mt-12 text-white">{t('welcome.WHAT_ARE_YOU_LOOKING_FOR')}</p>

            <div className="flex flex-col md:flex-row mt-6 gap-6 md:gap-2">
                <FormControl variant="filled" className="md:w-5/14 text-black rounded-lg px-4 py-4 md:py-2 lg:py-4 shadow-lg">
                    <InputLabel id="city">{t('destinations.SELECT_CITY')}</InputLabel>
                    <Controller
                        as={
                            <Select
                                className="rounded-lg"
                                labelId="city"
                                id="city">
                                <MenuItem value="">
                                    <em>{t('general.ALL')}</em>
                                </MenuItem>
                                {cities.map((city) => <MenuItem key={`status${city.id}`} value={city.id}>{city.i18n.find((item) => item.lang === lang).name}</MenuItem>)}
                            </Select>
                        }
                        control={control}
                        name="cityId" />
                </FormControl>
                <div className="flex md:flex-row gap-2 md:w-6/14">
                    <input type="hidden" name="type" ref={register} />
                    {/* <button
                        onClick={() => setValue('typeId', )}
                        type="button"
                        className="w-1/3 px-4 py-4 md:py-2 lg:py-4 outline-none rounded-lg bg-white text-primary shadow-2xl focus:outline-none">
                            {t('welcome.BUY')}
                    </button> */}
                    <button
                        onClick={() => setValue('type', 2)}
                        type="button"
                        className={`${watch('type') == 2 ? 'bg-primary text-white' : 'bg-white text-primary'} w-1/2 px-4 py-4 md:py-2 lg:py-4 outline-none rounded-lg shadow-2xl focus:outline-none`}>
                            {t('welcome.SELL')}
                    </button>
                    <button
                        onClick={() => setValue('type', 1)}
                        type="button"
                        className={`${watch('type') == 1 ? 'bg-primary text-white' : 'bg-white text-primary'} w-1/2 px-4 py-4 md:py-2 lg:py-4 outline-none rounded-lg shadow-2xl focus:outline-none`}>
                            {t('welcome.RENT')}
                    </button>
                </div>
                <button type="submit" className="w-full md:w-3/14 px-4 py-4 md:py-2 lg:py-4 outline-none uppercase bg-primary rounded-lg shadow-2xl focus:outline-none">{t('welcome.SEND_REQUEST')}</button>
            </div>
        </form>
    );
});

export default WelcomeForm;