import React, { memo, useCallback, useState, useRef } from 'react';
import {
    FormControlLabel,
    Checkbox,
    RadioGroup,
    Radio
} from '@material-ui/core';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { useTranslation } from '../../hooks';
import { contact } from '../../services';
import { currencyFormatter } from '../../utils';

import './Contact.css';

const formSchema = yup.object().shape({
    fullname: yup.string().required('message'),
    email: yup.string().required('message'),
    type: yup.string().required('message'),
    readyToPurchase: yup.boolean().required('message'),
    justExploring: yup.string().required('message'),
    budget: yup.number().required()
});

const Contact = memo(() => {
    const { handleSubmit, register, setValue, watch, reset } = useForm({
        resolver: yupResolver(formSchema),
        mode: 'all',
        defaultValues: {
            type: 'investment',
            readyToPurchase: 'true',
            justExploring: 'true',
            budget: 0
        }
    });
    const { t } = useTranslation();
    const [ isLoading, setIsLoading ] = useState(false);
    const [ showSuccessMsg, setShowSuccessMsg ] = useState(false);
    const rangeWrapperRef = useRef();
    const [budgetValue, setBudgetValue] = useState(2500);

    const onSubmit = useCallback((data) => {
        setIsLoading(true);
        contact(data)
            .then((response) => {
                reset();
                setShowSuccessMsg(true);
                setTimeout(() => setShowSuccessMsg(false), 4000);
            }).catch((error) => {
                console.error(error);
            }).then(() => setIsLoading(false));
    }, [reset, setIsLoading, setShowSuccessMsg]);

    return (
        <div className="py-6 md:py-12 bg-primary flex flex-col items-center">

            <div className="contact-form">

                <h2 className="text-3xl md:text-2xl text-white text-center">{t('contact.SECONDARY_MESSAGE')}</h2>
                <h3 className="text-3xl md:text-4xl text-white uppercase mt-8 md:mt-2 text-center">{t('contact.MAIN_MESSAGE')}</h3>

                <form
                    onSubmit={handleSubmit(onSubmit)}
                    className="mt-8 md:mt-16 bg-white rounded-lg">
                    <div className="w-full flex justify-center py-6 border-b border-customGray">
                        <p className="contact-form__title text-center">{t('contact.FORM_TITLE')}</p>
                    </div>


                    <div className="px-6 md:px-8 mt-6 flex">
                        <p className="text-sm md:text-md">1. {t('contact.FORM_QUESTION_1')}</p>
                    </div>
                    <div className="px-6 md:px-8 mt-6 flex">
                        <div className="w-1/2">
                            <input
                                placeholder={t('newsletter.FULL_NAME_LABEL')}
                                type="text"
                                name="fullname"
                                className={`${false ? 'border-red-500' : 'border-customGray'} py-2 px-4 rounded-lg border focus:outline-none`}
                                ref={register} />
                                {false && <span className="text-xs text-red-500">{t('errors.REQUIRED')}</span>}
                        </div>
                        <div className="w-1/2">
                            <input
                                placeholder={t('newsletter.FULL_NAME_LABEL')}
                                type="text"
                                name="email"
                                className={`${false ? 'border-red-500' : 'border-customGray'} py-2 px-4 rounded-lg border focus:outline-none`}
                                ref={register} />
                                {false && <span className="text-xs text-red-500">{t('errors.REQUIRED')}</span>}
                        </div>
                    </div>
                    <div className="px-6 md:px-8 py-6">
                        <div className="text-sm md:text-md">
                            <input type="hidden" name="type" ref={register} />
                            <p>2. {t('contact.FORM_QUESTION_2')}</p>
                            <div className="w-full flex flex-col md:flex-row justify-between mt-6 px-4">
                                <FormControlLabel
                                    control={<Checkbox checked={watch('type') === 'investment'}
                                    onChange={() => setValue('type', 'investment')} />}
                                    label={t('contact.FORM_QUESTION_2_OPTION_1')}/>
                                <FormControlLabel
                                    control={<Checkbox checked={watch('type') === 'partial'}
                                    onChange={() => setValue('type', 'partial')} />}
                                    label={t('contact.FORM_QUESTION_2_OPTION_2')}/>
                                <FormControlLabel
                                    control={<Checkbox checked={watch('type') === 'retirement'}
                                    onChange={() => setValue('type', 'retirement')} />}
                                    label={t('contact.FORM_QUESTION_2_OPTION_3')}/>
                            </div>
                        </div>
                    </div>
                    <div className="px-6 md:px-8 md:py-6 flex flex-col md:flex-row justify-between">
                        <div id="second-question" className="text-sm md:text-md">
                            <p>3. {t('contact.FORM_QUESTION_3')}</p>
                            <input type="hidden" name="readyToPurchase" ref={register} />
                            <RadioGroup
                                className="flex gap-12 mt-2 md:mt-6 px-8 md:px-4"
                                row>
                                <FormControlLabel
                                    checked={watch('readyToPurchase') === 'true'}
                                    control={<Radio />}
                                    onClick={() => setValue('readyToPurchase', 'true')}
                                    label={t('contact.FORM_QUESTION_3_OPTION_1')} />
                                <FormControlLabel
                                    checked={watch('readyToPurchase') === 'false'}
                                    control={<Radio />}
                                    onClick={() => setValue('readyToPurchase', 'false')}
                                    label={t('contact.FORM_QUESTION_3_OPTION_2')} />
                            </RadioGroup>
                        </div>
                        <div id="third-question" className="text-sm md:text-md">
                            <p>4. {t('contact.FORM_QUESTION_4')}</p>
                            <input type="hidden" name="justExploring" ref={register} />
                            <RadioGroup
                                className="flex gap-12 md:gap-0 md:justify-between mt-2 md:mt-6 px-8 md:px-4"
                                row>
                                <FormControlLabel
                                    checked={watch('justExploring') === 'true'}
                                    control={<Radio />}
                                    onClick={() => setValue('justExploring', 'true')}
                                    label={t('contact.FORM_QUESTION_4_OPTION_1')} />
                                <FormControlLabel
                                    checked={watch('justExploring') === 'false'}
                                    control={<Radio />}
                                    onClick={() => setValue('justExploring', 'false')}
                                    label={t('contact.FORM_QUESTION_4_OPTION_2')} />
                            </RadioGroup>
                        </div>
                    </div>
                    <div className="px-6 md:px-8 py-2 md:py-6 flex flex-col md:flex-row justify-between items-end">
                        <div className="w-full text-sm md:text-md">
                            <p>5. {t('contact.FORM_QUESTION_5')}</p>
                            <div className="range-wrap" ref={rangeWrapperRef}>
                                <input
                                    type="range"
                                    className="w-full mt-6 slider"
                                    name="budget"
                                    id="budget"
                                    min="25000"
                                    max="1000000"
                                    onInput={(e) => { setBudgetValue(e.target.value) }}
                                    ref={register} />
                                <output
                                    name="result ml-4"
                                    className="bubble">{currencyFormatter(budgetValue)} USD</output>
                            </div>
                        </div>
                        <div className="mt-4 md:mt-0 px-8 py-4 md-px-0 w-full">
                            {showSuccessMsg
                                ? <p className="text-primary text-center">{t('contact.EMAIL_SUCCESS_MESSAGE')}</p>
                                : <button
                                    disabled={isLoading}
                                    type="submit"
                                    className="bg-primary w-full text-white rounded-lg focus:outline-none"
                                    style={{height: '46px'}}>Send</button>}
                        </div>
                    </div>
                </form>
            </div>

            <div className="flex flex-col md:flex-row md:justify-between mt-8 md:mt-20 text-white info">
                <div className="flex flex-col">
                    <h5 className="text-2xl text-center">{t('contact.CALL')}</h5>
                    <div className="flex flex-col md:flex-row items-center mt-4 gap-2 md:gap-8 text-sm md:text-md">
                        <p>+52 1 (624) 174 35 81</p>
                        <p>USA - 1 (619) 796-3994</p>
                    </div>
                </div>
                <div className="flex flex-col mt-12 md:mt-0">
                    <h5 className="text-2xl text-center">{t('contact.WRITE')}</h5>
                    <p className="mt-4 underline text-center text-sm md:text-md">mexicolivingrealestate@gmail.com</p>
                </div>
            </div>
        </div>
    );
}, []);

export default Contact;