import { useContext } from 'react';
import { LangContext } from '../context';
import { ENStrings, ESStrings } from '../translations';


const langStrings = {
    es: ESStrings,
    en: ENStrings,
};

const useTranslation = () => {
    const { lang } = useContext(LangContext);

    const t = (keys) => {
        const [section, key] = keys.split('.');
        return langStrings[lang][section][key];
    }

    return { t, lang };
};

export default useTranslation;